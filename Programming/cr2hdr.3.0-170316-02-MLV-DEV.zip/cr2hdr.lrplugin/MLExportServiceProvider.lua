--[[

    cr2hdr.lrplugin is a plugin for Adobe Photoshop Lightroom
    to convert Dual ISO picture from Magic Lantern.
    http://www.magiclantern.fm/forum/index.php?topic=7139.0

    Copyright (C) <2015> <Christophe Francey kichetof@gmail.com>

    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License
    as published by the Free Software Foundation; either version 2
    of the License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

]]--

local LrApplication = import 'LrApplication'
local LrDialogs = import 'LrDialogs'
local LrLogger = import 'LrLogger'
local LrPathUtils = import 'LrPathUtils'
local LrPrefs = import 'LrPrefs'
local LrSystemInfo = import 'LrSystemInfo'
local LrTasks = import 'LrTasks'
local MLDialogs = require 'MLDialogs'
local MLProcess = require 'MLProcess'

local pluginInfo = require 'Info'
local helpers = require 'helpers'

local prefs = LrPrefs.prefsForPlugin()
local catalog = LrApplication:activeCatalog()

function getKeyForValue(t, value)
    for k,v in pairs(t) do
        if v==value then return k end
    end
    return nil
end

function inArray(t, value)
    for k, v in pairs(t) do
        if v == value then return k end
    end
    return false
end

function getLabelColor(propertyTable)

    local labelColor = catalog:getLabelMapToColorName()

    propertyTable.labels = {
        { value = "none", title = "" },
        { value = getKeyForValue(labelColor, "red"), title = getKeyForValue(labelColor, "red") },
        { value = getKeyForValue(labelColor, "green"), title = getKeyForValue(labelColor, "green") },
        { value = getKeyForValue(labelColor, "yellow"), title = getKeyForValue(labelColor, "yellow") },
        { value = getKeyForValue(labelColor, "blue"), title = getKeyForValue(labelColor, "blue") },
        { value = getKeyForValue(labelColor, "purple"), title = getKeyForValue(labelColor, "purple") },
    }

end

-- check for Adobe DNG Converter
function checkADNGC(propertyTable)
    local cmdADNGC = WIN_ENV and (LrSystemInfo.is64Bit() and 'dir /b "C:\\Program Files (x86)\\Adobe\\Adobe DNG Converter.exe"' or 'dir /b "C:\\Program Files\\Adobe\\Adobe DNG Converter.exe"') or 'exec ls "/Applications/Adobe DNG Converter.app/Contents/MacOS/Adobe DNG Converter"'
    propertyTable.hasADNGC = LrTasks.execute(cmdADNGC) == 0 and true or false
    propertyTable.compress = propertyTable.hasADNGC == true and propertyTable.compress or 0
end

-- check for Octave
function checkOctave(propertyTable)
    local cmdOct = WIN_ENV and 'dir /b "C:\\octave"' or 'exec ls "/Applications/Octave-cli.app"'
    propertyTable.hasOctave = LrTasks.execute(cmdOct) == 0 and true or false
    propertyTable.debug_rggb = propertyTable.hasOctave == true and propertyTable.debug_rggb or false
    propertyTable.debug_bddb = propertyTable.hasOctave == true and propertyTable.debug_bddb or false
    propertyTable.debug_bddb = propertyTable.hasOctave == true and propertyTable.debug_bddb or false
    propertyTable.debug_wb = propertyTable.hasOctave == true and propertyTable.debug_wb or false
    propertyTable.plot_iso_curve = propertyTable.hasOctave == true and propertyTable.plot_iso_curve or false
    propertyTable.plot_mix_curve = propertyTable.hasOctave == true and propertyTable.plot_mix_curve or false
    propertyTable.plot_fullres_curve = propertyTable.hasOctave == true and propertyTable.plot_fullres_curve or false
end

function checkSameLevels(propertyTable)
    
    if WIN_ENV then
        propertyTable.sameLevelPathStatus = false
        propertyTable.same_levels = propertyTable.same_levels == 2 and 1 or 0
        do return end
    end
    
    local folders = catalog:batchGetRawMetadata(catalog:getTargetPhotos(), { "path" })

    local paths = {}

    for _, folder in pairs (folders) do
        for k, v in pairs(folder) do
            if k == "path" then
                local tempFolder = LrPathUtils.parent(v)
                if not inArray(paths, tempFolder) then
                    paths[#paths+1] = tempFolder
                    mlLog:debugf("path %s", tempFolder)
                end
            end
        end
    end

    if propertyTable.same_levels == false then
        propertyTable.same_levels = 0
    elseif propertyTable.same_levels == true then
        propertyTable.same_levels = 1
    end

    if #catalog:getTargetPhotos() > 1 then
        propertyTable.sameLevelCmdStatus = true
    else
        propertyTable.sameLevelCmdStatus = false
        propertyTable.same_levels = 0
    end

    if #paths == 1 then
        local folder = catalog:getFolderByPath(paths[1])
        if #catalog:getTargetPhotos() == #folder:getPhotos(false) then
            propertyTable.sameLevelPathStatus = true
        else
            propertyTable.sameLevelPathStatus = false
            propertyTable.same_levels = propertyTable.same_levels ~= 2 and propertyTable.same_levels or 0
        end

    end

    if #paths > 1 then
        propertyTable.sameLevelPathStatus = false
        propertyTable.same_levels = propertyTable.same_levels ~= 2 and propertyTable.same_levels or 0
    end

end

-- var for log
mlLog = LrLogger('MLDualISO')
mlLog:enable("print") -- replace print with logfile to log into a file in ~/Documents on Mac OS, or My Documents on Windows
--mlLog:disable() -- uncomment it to disable log (only on release version)

--helpers.copyExportPreset() -- hard copy export preset to AppData, last way to fix Windows bug

local userSetCopyFilterPresets
--prefs.copyFilterPresets = nil
if prefs.copyFilterPresets == nil then
    userSetCopyFilterPresets = LrDialogs.confirm(
        LOC "$$$/ML/FPDialogQuestion=[Dual ISO Plugin] Do you want to install the presets for library filter?",
        LOC "$$$/ML/FPDialogInfo=You can disable the copy in the plugin manager (File -> Plug-In Manager)",
        LOC "$$$/ML/FPDialogOk=Ok, copy",
        LOC "$$$/ML/FPDialogCancel=No!")
    if userSetCopyFilterPresets ~= "ok" then
        prefs.copyFilterPresets = false
    end
end

if prefs.copyFilterPresets == true or userSetCopyFilterPresets == "ok" then
    prefs.copyFilterPresets = helpers.copyFilterPresets()
end

exportServiceProvider = {}

exportServiceProvider.canExportVideo = false

exportServiceProvider.exportPresetFields = {
    { key = 'synopsis_cr2hdr',      default = "use defaults" },
    { key = 'synopsis_plugin',      default = "use defaults" },
    { key = 'synopsis_export',      default = "use defaults" },
    { key = 'synopsis_metadata',    default = "use defaults" },
    { key = 'suffix',               default = "dualiso" },
    { key = 'keywords',             default = "" },
    { key = 'sync_keywords',        default = true },
    { key = 'label',                default = "none" },
    { key = 'labels',               default = {} },
    { key = 'rating',               default = 0 },
    { key = 'ratingLabel',          default = 0 .. "*" },
    { key = 'saveOutput',           default = true },
    { key = 'keepOriginalDNG',      default = true },
    { key = 'addToCollection',      default = true },
    { key = 'subfolder',            default = "" },
    { key = 'showSummary',          default = true },
    { key = 'flag',                 default = true },
    { key = 'shortcut_fast',        default = false },
    { key = 'interp_method',        default = 0 },      --0 amaze, 1 mean23
    { key = 'chroma_smooth_method', default = 2 },      --2 cs2, 3 cs3, 5 cs5, 0 no-cs
    { key = 'fix_bad_pixels',       default = 0 },      --1 bad, 2 really bad, 0 no bad
    { key = 'debug_bad_pixels',     default = false },
    { key = 'use_fullres',          default = 1 },      --0 no full, 1 full
    { key = 'use_alias_map',        default = 1 },      --0 no map, 1 map
    { key = 'use_stripe_fix',       default = 1 },      --0 no stripe, 1 stripe
    { key = 'compress',             default = 0 },      --0 no compress, 1 compress, 2 compress lossy
    { key = 'soft_film',            default = 0 },      --float value 0 to 10
    { key = 'gray_wb',              default = 0 },      --0 graymax, 1 graymed, 2 exif, 3 dcraw camera multipliers -1 inactiv
    { key = 'same_levels',          default = 0 },      --0 no same-levels, 1 same-levels cmd, 2 same-levels path
    { key = 'skip_existing',        default = false },
    { key = 'embed_original',       default = false },
    { key = 'debug_blend',          default = false },
    { key = 'debug_black',          default = false },
    { key = 'debug_amaze',          default = false },
    { key = 'debug_edge',           default = false },
    { key = 'debug_alias',          default = false },
    { key = 'debug_bddb',           default = false },
    { key = 'debug_rggb',           default = false },
    { key = 'debug_wb',             default = false },
    { key = 'plot_iso_curve',       default = false },
    { key = 'plot_mix_curve',       default = false },
    { key = 'plot_fullres_curve',   default = false },
    { key = 'hasADNGC',             default = true },      --true ADNGC installed or false
    { key = 'hasOctave',            default = true },      --true Octave installed or false
    { key = 'syncDevelopParams',    default = true },
    { key = 'sameLevelDisable',     default = true },
    { key = 'sameLevelCmdStatus',   default = false },
    { key = 'sameLevelPathStatus',  default = false },
}

exportServiceProvider.hideSections = { "exportLocation", "fileNaming", "fileSettings", "imageSettings", "outputSharpening", "metadata", "watermarking", "video" }

function exportServiceProvider.startDialog(propertyTable)

    if string.find(string.lower(pluginInfo.VERSION.display), "dev") ~= nil then
       LrDialogs.message("This version is currently in developpment!\n\nKeep in mind that there might have some bugs...", string.format("Please report any issues to:\nhttps://bitbucket.org/kichetof/lr_cr2hdr/issues\n\nVersion %s\n\n(to disable this warning, remove '-dev' in plugin version display variable in Info.lua file)", pluginInfo.VERSION.display), "info")
    end

    MLDialogs.checkDefaultsExport(propertyTable)
    MLDialogs.checkDefaultsMetadata(propertyTable)
    MLDialogs.checkDefaultsExec(propertyTable)

    LrTasks.startAsyncTask(function ()
        checkSameLevels(propertyTable)
        getLabelColor(propertyTable)
        checkADNGC(propertyTable)
        checkOctave(propertyTable)
    end)

end

function exportServiceProvider.endDialog( propertyTable )

    propertyTable.LR_tokens = string.format("{{image_name}}-%s", propertyTable.suffix)
    propertyTable.LR_format = 'ORIGINAL'
    propertyTable.LR_export_colorSpace = "AdobeRGB"

end

function exportServiceProvider.updateExportSettings(exportSettings)

    mlLog:debug("I'm called before exportServiceProvider.processRenderedPhotos")

end

function exportServiceProvider.processRenderedPhotos(functionContext, exportContext)

    return MLProcess.process(functionContext, exportContext)

end

function exportServiceProvider.sectionsForTopOfDialog(f, propertyTable)

    return MLDialogs.settings(f, propertyTable)

end

return exportServiceProvider
