--[[

    cr2hdr.lrplugin is a plugin for Adobe Photoshop Lightroom
    to convert Dual ISO picture from Magic Lantern.
    http://www.magiclantern.fm/forum/index.php?topic=7139.0

    Copyright (C) <2015> <Christophe Francey kichetof@gmail.com>

    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License
    as published by the Free Software Foundation; either version 2
    of the License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

]]--

local LrBinding = import 'LrBinding'
local LrColor = import 'LrColor'
local LrDialogs = import 'LrDialogs'
local LrView = import "LrView"

local pluginInfo = require 'Info'

local bind = LrView.bind
local share = LrView.share

local MLDialogs = {}

-- Update optional arguments when --fast is selected
function MLDialogs.updateArguments(propertyTable)
    if propertyTable.shortcut_fast then
        propertyTable.interp_method = 1
        propertyTable.chroma_smooth_method = 0
        propertyTable.use_fullres = 0
        propertyTable.use_alias_map = 0
        propertyTable.use_stripe_fix = 0
    else
        propertyTable.interp_method = 0
        propertyTable.chroma_smooth_method = 2
        propertyTable.use_fullres = 1
        propertyTable.use_alias_map = 1
        propertyTable.use_stripe_fix = 1
    end
end

function MLDialogs.setWbToDefault(pt)
    if pt.same_levels > 0 then
        pt.gray_wb = 0
        pt.sameLevelDisable = false
    else
        pt.sameLevelDisable = true
    end
end

function MLDialogs.checkDefaultsExport(pt)
    local default = {}
    local info = ""
    table.insert(default, pt.suffix == "dualiso" and true or false)
    table.insert(default, pt.subfolder == "" and true or false)
    table.insert(default, pt.showSummary == true and true or false)
    table.insert(default, pt.saveOutput == true and true or false)
    table.insert(default, pt.keepOriginalDNG == true and true or false)
    table.insert(default, pt.syncDevelopParams == true and true or false)
    for k, v in pairs(default) do
        if v == false then
            pt.synopsis_export = LOC("$$$/ML/ExportManager/SynopsisModuleCustom=Use custom settings^1", info)
            return false
        end
    end
    pt.synopsis_export = LOC("$$$/ML/ExportManager/SynopsisModuleDefault=Use default settings^1", info)
    return true
end

function MLDialogs.checkDefaultsMetadata(pt)
    local default = {}
    local info = ""
    table.insert(default, pt.keywords == "" and true or false)
    table.insert(default, pt.sync_keywords == true and true or false)
    table.insert(default, pt.label == "none" and true or false)
    table.insert(default, pt.rating == 0 and true or false)
    table.insert(default, pt.addToCollection == true and true or false)
    table.insert(default, pt.flag == true and true or false)
    for k, v in pairs(default) do
        if v == false then
            pt.synopsis_metadata = LOC("$$$/ML/ExportManager/SynopsisModuleCustom=Use custom settings^1", info)
            return false
        end
    end
    pt.synopsis_metadata = LOC("$$$/ML/ExportManager/SynopsisModuleDefault=Use default settings^1", info)
    return true
end

function MLDialogs.checkDefaultsExec(pt)
    local default = {}
    local info = ""
    table.insert(default, pt.shortcut_fast == false and true or false)
    table.insert(default, pt.interp_method == 0 and true or false)
    table.insert(default, pt.chroma_smooth_method == 2 and true or false)
    table.insert(default, pt.fix_bad_pixels == 0 and true or false)
    table.insert(default, pt.debug_bad_pixels == false and true or false)
    table.insert(default, pt.use_fullres == 1 and true or false)
    table.insert(default, pt.use_alias_map == 1 and true or false)
    table.insert(default, pt.use_stripe_fix == 1 and true or false)
    table.insert(default, pt.compress == 0 and true or false)
    table.insert(default, pt.debug_blend == false and true or false)
    table.insert(default, pt.debug_black == false and true or false)
    table.insert(default, pt.debug_amaze == false and true or false)
    table.insert(default, pt.debug_edge == false and true or false)
    table.insert(default, pt.debug_alias == false and true or false)
    table.insert(default, pt.plot_iso_curve == false and true or false)
    table.insert(default, pt.plot_mix_curve == false and true or false)
    table.insert(default, pt.plot_fullres_curve == false and true or false)

    table.insert(default, pt.soft_film == 0 and true or false)
    table.insert(default, pt.gray_wb == 0 and true or false)
    table.insert(default, pt.same_levels == 0 and true or false)
    table.insert(default, pt.skip_existing == false and true or false)
    table.insert(default, pt.embed_original == false and true or false)
    table.insert(default, pt.debug_rggb == false and true or false)
    table.insert(default, pt.debug_bddb == false and true or false)
    table.insert(default, pt.debug_wb == false and true or false)

    for k, v in pairs(default) do
        if v == false then
            pt.synopsis_cr2hdr = LOC("$$$/ML/ExportManager/SynopsisModuleCustom=Use custom settings^1", info)
            return false
        end
    end
    pt.synopsis_cr2hdr = LOC("$$$/ML/ExportManager/SynopsisModuleDefault=Use default settings^1", info)
    return true
end

function MLDialogs.ResetExport(propertyTable)
    propertyTable.suffix = "dualiso"
    propertyTable.saveOutput = true
    propertyTable.subfolder = ""
    propertyTable.showSummary = true
    propertyTable.keepOriginalDNG = true
    propertyTable.syncDevelopParams = true
end

function MLDialogs.ResetMetadata(propertyTable)
    propertyTable.keywords = ""
    propertyTable.sync_keywords = true
    propertyTable.label = "none"
    propertyTable.rating = 0
    propertyTable.addToCollection = true
    propertyTable.flag = true
end

function MLDialogs.ResetExec(propertyTable)
    propertyTable.shortcut_fast = false
    propertyTable.interp_method = 0
    propertyTable.chroma_smooth_method = 2
    propertyTable.fix_bad_pixels = 0
    propertyTable.debug_bad_pixels = false
    propertyTable.use_fullres = 1
    propertyTable.use_alias_map = 1
    propertyTable.use_stripe_fix = 1
    propertyTable.compress = 0
    propertyTable.soft_film = 0
    propertyTable.gray_wb = 0
    propertyTable.same_levels = 0
    propertyTable.skip_existing = false
    propertyTable.embed_original = false
    propertyTable.debug_blend = false
    propertyTable.debug_black = false
    propertyTable.debug_amaze = false
    propertyTable.debug_edge = false
    propertyTable.debug_alias = false
    propertyTable.plot_iso_curve = false
    propertyTable.plot_mix_curve = false
    propertyTable.plot_fullres_curve = false
    propertyTable.debug_rggb = false
    propertyTable.debug_bddb = false
    propertyTable.debug_wb = false
end

function MLDialogs.checkSuffixExists(propertyTable)
    if propertyTable.suffix == "" and propertyTable.keepOriginalDNG == false then
        LrDialogs.message(LOC "$$$/ML/ExportManager/KeepOriginalAlertNoSuffix=If you want to remove DNG file after conversion, you need to set a suffix.")
    end

    if propertyTable.suffix == "" then
        propertyTable.keepOriginalDNG = true
    end
end

function MLDialogs.settings(f, propertyTable)
    local ExecLabelColor = LrColor("dark gray")
    local OctaveLabelColor = LrColor("orange")
    local labelAlignment = "left"
    local labelSize = "mini"
    local radioTextSize = "small"
    local spacerHeight = 25

    propertyTable:addObserver("shortcut_fast", MLDialogs.updateArguments)

    propertyTable:addObserver('suffix', MLDialogs.checkDefaultsExport)
    propertyTable:addObserver('subfolder', MLDialogs.checkDefaultsExport)
    propertyTable:addObserver('showSummary', MLDialogs.checkDefaultsExport)
    propertyTable:addObserver('saveOutput', MLDialogs.checkDefaultsExport)
    propertyTable:addObserver('keepOriginalDNG', MLDialogs.checkDefaultsExport)
    propertyTable:addObserver('syncDevelopParams', MLDialogs.checkDefaultsExport)

    propertyTable:addObserver('keywords', MLDialogs.checkDefaultsMetadata)
    propertyTable:addObserver('label', MLDialogs.checkDefaultsMetadata)
    propertyTable:addObserver('rating', MLDialogs.checkDefaultsMetadata)
    propertyTable:addObserver('addToCollection', MLDialogs.checkDefaultsMetadata)
    propertyTable:addObserver('flag', MLDialogs.checkDefaultsMetadata)

    propertyTable:addObserver('shortcut_fast', MLDialogs.checkDefaultsExec)
    propertyTable:addObserver('interp_method', MLDialogs.checkDefaultsExec)
    propertyTable:addObserver('chroma_smooth_method', MLDialogs.checkDefaultsExec)
    propertyTable:addObserver('fix_bad_pixels', MLDialogs.checkDefaultsExec)
    propertyTable:addObserver('debug_bad_pixels', MLDialogs.checkDefaultsExec)
    propertyTable:addObserver('use_fullres', MLDialogs.checkDefaultsExec)
    propertyTable:addObserver('use_alias_map', MLDialogs.checkDefaultsExec)
    propertyTable:addObserver('use_stripe_fix', MLDialogs.checkDefaultsExec)
    propertyTable:addObserver('compress', MLDialogs.checkDefaultsExec)
    propertyTable:addObserver('soft_film', MLDialogs.checkDefaultsExec)
    propertyTable:addObserver('gray_wb', MLDialogs.checkDefaultsExec)
    propertyTable:addObserver('same_levels', MLDialogs.checkDefaultsExec)
    propertyTable:addObserver('skip_existing', MLDialogs.checkDefaultsExec)
    propertyTable:addObserver('embed_original', MLDialogs.checkDefaultsExec)
    propertyTable:addObserver('debug_blend', MLDialogs.checkDefaultsExec)
    propertyTable:addObserver('debug_black', MLDialogs.checkDefaultsExec)
    propertyTable:addObserver('debug_amaze', MLDialogs.checkDefaultsExec)
    propertyTable:addObserver('debug_edge', MLDialogs.checkDefaultsExec)
    propertyTable:addObserver('debug_alias', MLDialogs.checkDefaultsExec)
    propertyTable:addObserver('debug_rggb', MLDialogs.checkDefaultsExec)
    propertyTable:addObserver('debug_bddb', MLDialogs.checkDefaultsExec)
    propertyTable:addObserver('debug_wb', MLDialogs.checkDefaultsExec)
    propertyTable:addObserver('plot_iso_curve', MLDialogs.checkDefaultsExec)
    propertyTable:addObserver('plot_mix_curve', MLDialogs.checkDefaultsExec)
    propertyTable:addObserver('plot_fullres_curve', MLDialogs.checkDefaultsExec)

    propertyTable:addObserver('same_levels', MLDialogs.setWbToDefault)

    propertyTable:addObserver('suffix', MLDialogs.checkSuffixExists)
    propertyTable:addObserver('keepOriginalDNG', MLDialogs.checkSuffixExists)

    local sectionTitle = {
        title = LOC ("$$$/ML/ExportManager/Title=Magic Lantern Dual ISO (Plugin version ^1)", pluginInfo.VERSION.display),
        f:row {
            margin_left = 20,
            f:picture {
                value = _PLUGIN:resourceId("lr_cr2hdr_logo.png"),
            },
        },
    }
    local sectionExec = {
        title = LOC "$$$/ML/ExportManager/CRTitle=cr2hdr optional arguments",
        synopsis = bind 'synopsis_cr2hdr',
        visible = false,
        f:tab_view {
            value = "CRTab1",
            fill_horizontal = 1,
            f:tab_view_item {
                title = LOC "$$$/ML/ExportManager/CRTab1=Arguments",
                identifier = "CRTab1",
                f:column {
                    spacing = f:control_spacing(),
                    fill_horizontal = 1,
                    f:row {
                        f:static_text {
                            width = share 'labelExecWidth',
                            title = LOC "$$$/ML/ExportManager/CRTab1Shortcuts=Shortcuts:",
                            alignment = labelAlignment,
                            size = labelSize,
                        },
                        f:checkbox {
                            size = "small",
                            tooltip = LOC "$$$/ML/ExportManager/TTFast=disable most postprocessing steps (fast, but low quality)\n(--mean23, --no-cs, --no-fullres, --no-alias-map, --no-stripe-fix, --no-bad-pix)",
                            value = bind 'shortcut_fast',
                            checked_value = true,
                            unchecked_value = false,
                        },
                        f:static_text {
                            text_color = ExecLabelColor,
                            title = "fast",
                        },
                        f:spacer {
                            height = spacerHeight,
                        },
                    },
                    f:view {
                        place = horizontal,
                        f:row {
                            f:static_text {
                                width = share 'labelExecWidth',
                                title = LOC "$$$/ML/ExportManager/CRTab1IM=Interpolation methods",
                                alignment = labelAlignment,
                                size = labelSize,
                            },
                            f:radio_button {
                                size = "small",
                                tooltip = LOC "$$$/ML/ExportManager/TTAmaze=use a temporary demosaic step (AMaZE) followed by edge-directed interpolation (default)",
                                value = bind 'interp_method',
                                checked_value = 0,
                            },
                            f:static_text {
                                text_color = ExecLabelColor,
                                title = "amaze-edge",
                                width = share 'radioExecWidth1',
                            },
                            f:radio_button {
                                size = "small",
                                tooltip = LOC "$$$/ML/ExportManager/TTMean=average the nearest 2 or 3 pixels of the same color from the Bayer grid (faster)",
                                value = bind 'interp_method',
                                checked_value = 1,
                            },
                            f:static_text {
                                text_color = ExecLabelColor,
                                title = "mean23",
                                width = share 'radioExecWidth1',
                            },
                        },
                    },
                    f:view {
                        place = horizontal,
                        f:row {
                            f:static_text {
                                width = share 'labelExecWidth',
                                title = LOC "$$$/ML/ExportManager/CRTab2Cs=Chroma smoothing:",
                                alignment = labelAlignment,
                                size = labelSize,
                            },
                            f:radio_button {
                                size = "small",
                                tooltip = LOC "$$$/ML/ExportManager/TTNoCs=disable chroma smoothing",
                                value = bind 'chroma_smooth_method',
                                checked_value = 0,
                            },
                            f:static_text {
                                text_color = ExecLabelColor,
                                title = "no-cs",
                                width = share 'radioExecWidth1',
                            },
                            f:radio_button {
                                size = "small",
                                tooltip = LOC "$$$/ML/ExportManager/TTCs2=apply 2x2 chroma smoothing in noisy and aliased areas (default)",
                                value = bind 'chroma_smooth_method',
                                checked_value = 2,
                            },
                            f:static_text {
                                text_color = ExecLabelColor,
                                title = "cs2x2",
                                width = share 'radioExecWidth1',
                            },
                            f:radio_button {
                                size = "small",
                                tooltip = LOC "$$$/ML/ExportManager/TTCs3=apply 3x3 chroma smoothing in noisy and aliased areas",
                                value = bind 'chroma_smooth_method',
                                checked_value = 3,
                            },
                            f:static_text {
                                text_color = ExecLabelColor,
                                title = "cs3x3",
                                width = share 'radioExecWidth1',
                            },
                            f:radio_button {
                                size = "small",
                                tooltip = LOC "$$$/ML/ExportManager/TTCs5=apply 5x5 chroma smoothing in noisy and aliased areas",
                                value = bind 'chroma_smooth_method',
                            checked_value = 5,
                            },
                            f:static_text {
                                text_color = ExecLabelColor,
                                title = "cs5x5",
                                width = share 'radioExecWidth1',
                            },
                        },
                    },
                    f:view {
                        place = horizontal,
                        f:row {
                            f:static_text {
                                width = share 'labelExecWidth',
                                title = LOC "$$$/ML/ExportManager/CRTab1Bph=Bad pixel handling:",
                                alignment = labelAlignment,
                                size = labelSize,
                            },
                            f:radio_button {
                                size = "small",
                                tooltip = LOC "$$$/ML/ExportManager/TTNoBadPix=disable bad pixel fixing (try it if you shoot stars)",
                                value = bind 'fix_bad_pixels',
                                checked_value = 0,
                            },
                            f:static_text {
                                text_color = ExecLabelColor,
                                title = "no-bad-pix",
                                width = share 'radioExecWidth1',
                            },
                            f:radio_button {
                                size = "small",
                                tooltip = "",
                                value = bind 'fix_bad_pixels',
                                checked_value = 1,
                            },
                            f:static_text {
                                text_color = ExecLabelColor,
                                title = "bad-pix",
                                width = share 'radioExecWidth1',
                            },
                            f:radio_button {
                                size = "small",
                                tooltip = LOC "$$$/ML/ExportManager/TTRBadPix=aggressive bad pixel fix, at the expense of detail and aliasing",
                                value = bind 'fix_bad_pixels',
                            checked_value = 2,
                            },
                            f:static_text {
                                text_color = ExecLabelColor,
                                title = "really-bad-pix",
                                width = share 'radioExecWidth1',
                            },
                        },
                    },
                    f:row {
                        f:spacer {
                            width = share 'labelExecWidth',
                        },
                        f:checkbox {
                            size = "small",
                            tooltip = LOC "$$$/ML/ExportManager/TTBBadPix=mark all bad pixels as black (for troubleshooting)",
                            value = bind 'debug_bad_pixels',
                            checked_value = true,
                            unchecked_value = false,
                        },
                        f:static_text {
                            text_color = ExecLabelColor,
                            title = "black-bad-pix",
                            width = share 'radioExecWidth1',
                        },
                    },
                    f:view {
                        place = horizontal,
                        f:row {
                            f:static_text {
                                width = share 'labelExecWidth',
                                title = LOC "$$$/ML/ExportManager/CRTab1Opp=Other postprocessing:",
                                alignment = labelAlignment,
                                size = labelSize,
                            },
                            f:radio_button {
                                size = "small",
                                tooltip = LOC "$$$/ML/ExportManager/TTNoFRes=disable full-resolution blending",
                                value = bind 'use_fullres',
                                checked_value = 0,
                            },
                            f:static_text {
                                text_color = ExecLabelColor,
                                title = "no-fullres",
                                width = share 'radioExecWidth1',
                            },
                            f:radio_button {
                                size = "small",
                                tooltip = "",
                                value = bind 'use_fullres',
                                checked_value = 1,
                            },
                            f:static_text {
                                text_color = ExecLabelColor,
                                title = "fullres",
                                width = share 'radioExecWidth1',
                            },
                        },
                    },
                    f:view {
                        place = horizontal,
                        f:row {
                            f:spacer {
                                width = share 'labelExecWidth',
                            },
                            f:radio_button {
                                size = "small",
                                tooltip = LOC "$$$/ML/ExportManager/TTNoAlias=disable alias map, used to fix aliasing in deep shadows",
                                value = bind 'use_alias_map',
                                checked_value = 0,
                            },
                            f:static_text {
                                text_color = ExecLabelColor,
                                title = "no-alias-map",
                                width = share 'radioExecWidth1',
                            },
                            f:radio_button {
                                size = "small",
                                tooltip = "",
                                value = bind 'use_alias_map',
                                checked_value = 1,
                            },
                            f:static_text {
                                text_color = ExecLabelColor,
                                title = "alias-map",
                                width = share 'radioExecWidth1',
                            },
                        },
                    },
                    f:view {
                        place = horizontal,
                        f:row {
                            f:spacer {
                                width = share 'labelExecWidth',
                            },
                            f:radio_button {
                                size = "small",
                                tooltip = LOC "$$$/ML/ExportManager/TTNoStrip=disable horizontal stripe fix",
                                value = bind 'use_stripe_fix',
                                checked_value = 0,
                            },
                            f:static_text {
                                text_color = ExecLabelColor,
                                title = "no-stripe-fix",
                                width = share 'radioExecWidth1',
                            },
                            f:radio_button {
                                size = "small",
                                tooltip = "",
                                value = bind 'use_stripe_fix',
                                checked_value = 1,
                            },
                            f:static_text {
                                text_color = ExecLabelColor,
                                title = "stripe-fix",
                                width = share 'radioExecWidth1',
                            },
                        },
                    },
                    f:view {
                        place = horizontal,
                        f:row {
                            f:static_text {
                            width = share 'labelExecWidth',
                            title = LOC "$$$/ML/ExportManager/CRTab1DNGcomp=DNG compression:",
                            alignment = labelAlignment,
                            size = labelSize,
                        },
                        f:radio_button {
                            size = "small",
                            tooltip = LOC "$$$/ML/ExportManager/TTNoCompress=No compression:",
                            value = bind 'compress',
                            checked_value = 0,
                        },
                        f:static_text {
                            text_color = ExecLabelColor,
                            title = "no-compress",
                            width = share 'radioExecWidth1',
                        },
                        f:radio_button {
                            size = "small",
                            tooltip = LOC "$$$/ML/ExportManager/TTCompress=Lossless DNG compression:",
                            value = bind 'compress',
                            checked_value = 1,
                            enabled = bind 'hasADNGC',
                        },
                        f:static_text {
                            text_color = ExecLabelColor,
                            title = "compress",
                            width = share 'radioExecWidth1',
                        },
                        f:radio_button {
                            size = "small",
                            tooltip = LOC "$$$/ML/ExportManager/TTCompressLossy=Lossy DNG compression (be careful, may destroy shadow detail)",
                            value = bind 'compress',
                            checked_value = 2,
                            enabled = bind 'hasADNGC',
                        },
                        f:static_text {
                            text_color = ExecLabelColor,
                            title = "compress-lossy",
                            width = share 'radioExecWidth1',
                        },
                    },
                },
                f:column {
                    spacing = f:control_spacing(),
                    fill_horizontal = 1,
                    f:row {
                        f:static_text {
                            width = share 'labelExecWidth',
                            title = LOC "$$$/ML/ExportManager/CRTab2Hs=Highlight/shadow:",
                            alignment = labelAlignment,
                            size = labelSize,
                        },
                        f:static_text {
                            title = "soft-film",
                            text_color = ExecLabelColor,
                        },
                        f:slider {
                            value = bind 'soft_film',
                            min = 0,
                            max = 10,
                            tooltip = LOC "$$$/ML/ExportManager/TTSoftFilm=bake a soft-film curve to compress highlights and raise shadows by X EV\n(if you use this option, you should also specify the white balance)",
                            integral = true,
                        },
                        f:static_text{
                            title = bind 'soft_film',
                            text_color = LrColor("gray"),
                        },
                        f:spacer {
                            height = spacerHeight,
                        },
                    },
                    f:view {
                        place = horizontal,
                        f:row {
                            f:static_text {
                                width = share 'labelExecWidth',
                                title = LOC "$$$/ML/ExportManager/CRTab2Wb=White balance:",
                                alignment = labelAlignment,
                                size = labelSize,
                            },
                            f:radio_button {
                                size = "small",
                                tooltip = LOC "$$$/ML/ExportManager/TTNoWb=Don't set AsShotNeutral",
                                value = bind 'gray_wb',
                                checked_value = -1,
                            },
                            f:static_text {
                                text_color = ExecLabelColor,
                                title = "no-wb",
                                width = share 'radioExecWidth1',
                            },
                            f:radio_button {
                                size = "small",
                                tooltip = LOC "$$$/ML/ExportManager/TTWbGrayMax=set AsShotNeutral by maximizing the number of gray pixels (default)",
                                value = bind 'gray_wb',
                                checked_value = 0,
                            },
                            f:static_text {
                                text_color = ExecLabelColor,
                                title = "wb=graymax",
                                width = share 'radioExecWidth1',
                            },
                            f:radio_button {
                                size = "small",
                                tooltip = LOC "$$$/ML/ExportManager/TTWbGrayMed=set AsShotNeutral from the median of R-G and B-G",
                                value = bind 'gray_wb',
                                checked_value = 1,
                            },
                            f:static_text {
                                text_color = ExecLabelColor,
                                title = "wb=graymed",
                                width = share 'radioExecWidth1',
                            },
                        },
                    },
                    f:view {
                        place = horizontal,
                        f:row {
                            f:spacer {
                                width = share 'labelExecWidth',
                            },
                            f:radio_button {
                                size = "small",
                                tooltip = LOC "$$$/ML/ExportManager/TTWbExif=set AsShotNeutral from EXIF WB (not exactly working)",
                                value = bind 'gray_wb',
                                checked_value = 2,
                            },
                            f:static_text {
                                text_color = ExecLabelColor,
                                title = "wb=exif",
                                width = share 'radioExecWidth1',
                            },
                            f:radio_button {
                                size = "small",
                                tooltip = LOC "$$$/ML/ExportManager/TTWbDcraw=set AsShotNeutral from dcraw camera multipliers",
                                value = bind 'gray_wb',
                                checked_value = 3,
                                enabled = bind 'sameLevelDisable',
                            },
                            f:static_text {
                                text_color = ExecLabelColor,
                                title = "wb=dcraw",
                                width = share 'radioExecWidth1',
                            },
                        },
                    },
                    f:row {
                        f:static_text {
                            width = share 'labelExecWidth',
                            title = LOC "$$$/ML/ExportManager/CRTab2Fh=Flicker handling:",
                            alignment = labelAlignment,
                            size = labelSize,
                        },
                        f:radio_button {
                            size = "small",
                            tooltip = LOC "$$$/ML/ExportManager/TTNoSameLevels=Don't Adjust output white levels to keep the same overall exposure",
                            value = bind 'same_levels',
                            checked_value = 0,
                        },
                        f:static_text {
                            text_color = ExecLabelColor,
                            title = "no-same-levels",
                            width = share 'radioExecWidth1',
                        },
                        f:radio_button {
                            size = "small",
                            tooltip = LOC "$$$/ML/ExportManager/TTSameLevels=Adjust output white levels to keep the same overall exposure\nfor all frames passed in a single command line\n(useful to avoid flicker - for video or panoramas)",
                            value = bind 'same_levels',
                            checked_value = 1,
                            enabled = bind 'sameLevelCmdStatus',
                        },
                        f:static_text {
                            text_color = ExecLabelColor,
                            title = "same-levels",
                            width = share 'radioExecWidth1',
                            enabled = bind 'sameLevelCmdStatus',
                        },
                        f:radio_button {
                            size = "small",
                            tooltip = LOC "$$$/ML/ExportManager/TTSameLevels=Adjust output white levels to keep the same overall exposure\nfor all frames passed in a single command line\n(useful to avoid flicker - for video or panoramas)",
                            value = bind 'same_levels',
                            checked_value = 2,
                            enabled = bind 'sameLevelPathStatus',
                        },
                        f:static_text {
                            text_color = ExecLabelColor,
                            title = "same-levels on entire path",
                            --width = share 'radioExecWidth',
                            enabled = bind 'sameLevelPathStatus',
                        },
                    },
                    f:row {
                        f:static_text {
                            width = share 'labelExecWidth',
                            title = LOC "$$$/ML/ExportManager/CRTab2MS=Misc settings:",
                            alignment = labelAlignment,
                            size = labelSize,
                        },
                        f:checkbox {
                            size = "small",
                            tooltip = LOC "$$$/ML/ExportManager/TTSkipExisting=Skip the conversion if the output file already exists",
                            value = bind 'skip_existing',
                            checked_value = true,
                            unchecked_value = false,
                        },
                        f:static_text {
                            text_color = ExecLabelColor,
                            title = "skip-existing",
                            width = share 'radioExecWidth',
                        },
                        f:checkbox {
                            size = "small",
                            tooltip = LOC "$$$/ML/ExportManager/TTEmbedOriginal=Embed the original CR2 file in the output DNG, and keep the CR2\nYou will be able to re-process the DNG with a different version or different conversion settings.\nTo recover the original RAW: exiftool IMG_1234.DNG -OriginalRawFileData -b > IMG_1234.CR2",
                            value = bind 'embed_original',
                            checked_value = true,
                            unchecked_value = false,
                        },
                        f:static_text {
                            text_color = ExecLabelColor,
                            title = "embed-original-copy",
                            width = share 'radioExecWidth',
                        },
                    },
                },
            },
        },
        f:tab_view_item {
            title = LOC "$$$/ML/ExportManager/CRTab3=Troubleshooting",
            identifier = "CRTab3",
            f:column {
                spacing = f:control_spacing(),
                fill_horizontal = 1,
                f:row {
                    f:static_text {
                        width = share 'labelExecWidth',
                        title = LOC "$$$/ML/ExportManager/CRTab3Ts=Troubleshooting:",
                        alignment = labelAlignment,
                        size = labelSize,
                    },
                    f:checkbox {
                        size = "small",
                        tooltip = LOC "$$$/ML/ExportManager/TTDebugBlend=save intermediate images used for blending:\n    dark.dng        the low-ISO exposure, interpolated\n    bright.dng      the high-ISO exposure, interpolated and darkened\n    halfres.dng     half-resolution blending (low noise, high aliasing)\n    fullres.dng     full-resolution blending (minimal aliasing, high noise)\n    *_smooth.dng    images after chroma smoothing",
                        value = bind 'debug_blend',
                        checked_value = true,
                        unchecked_value = false,
                    },
                    f:static_text {
                        text_color = ExecLabelColor,
                        title = "debug-blend",
                        width = share 'labelDebugWidth',
                    }
                },
                f:row {
                    f:spacer {
                        width = share 'labelExecWidth',
                    },
                    f:checkbox {
                        size = "small",
                        tooltip = LOC "$$$/ML/ExportManager/TTDebugBlack=save intermediate images used for black level subtraction",
                        value = bind 'debug_black',
                        checked_value = true,
                        unchecked_value = false,
                    },
                    f:static_text {
                        text_color = ExecLabelColor,
                        title = "debug-black",
                        width = share 'labelDebugWidth',
                    }
                },
                f:row {
                    f:spacer {
                        width = share 'labelExecWidth',
                    },
                    f:checkbox {
                        size = "small",
                        tooltip = LOC "$$$/ML/ExportManager/TTDebugAmaze=save AMaZE input and output",
                        value = bind 'debug_amaze',
                        checked_value = true,
                        unchecked_value = false,
                    },
                    f:static_text {
                        text_color = ExecLabelColor,
                        title = "debug-amaze",
                        width = share 'labelDebugWidth',
                    }
                },
                f:row {
                    f:spacer {
                        width = share 'labelExecWidth',
                    },
                    f:checkbox {
                        size = "small",
                        tooltip = LOC "$$$/ML/ExportManager/TTDebugEdge=save debug info from edge-directed interpolation",
                        value = bind 'debug_edge',
                        checked_value = true,
                        unchecked_value = false,
                    },
                    f:static_text {
                        text_color = ExecLabelColor,
                        title = "debug-edge",
                        width = share 'labelDebugWidth',
                    }
                },
                f:row {
                    f:spacer {
                        width = share 'labelExecWidth',
                    },
                    f:checkbox {
                        size = "small",
                        tooltip = LOC "$$$/ML/ExportManager/TTDebugAlias=save debug info about the alias map",
                        value = bind 'debug_alias',
                        checked_value = true,
                        unchecked_value = false,
                    },
                    f:static_text {
                        text_color = ExecLabelColor,
                        title = "debug-alias",
                        width = share 'labelDebugWidth',
                    }
                },
                f:row {
                    f:spacer {
                        width = share 'labelExecWidth',
                    },
                    f:checkbox {
                        size = "small",
                        tooltip = LOC "$$$/ML/ExportManager/TTDebugRggb=plot debug info for RGGB/BGGR autodetection (requires octave)",
                        value = bind 'debug_rggb',
                        checked_value = true,
                        unchecked_value = false,
                        enabled = bind 'hasOctave',
                    },
                    f:static_text {
                        text_color = ExecLabelColor,
                        title = "debug-rggb",
                        width = share 'labelDebugWidth',
                    },
                    f:spacer {
                        width = share 'labelWarning',
                    },
                    f:static_text {
                        text_color = OctaveLabelColor,
                        title = "(requires octave)",
                    }
                },
                f:row {
                    f:spacer {
                        width = share 'labelExecWidth',
                    },
                    f:checkbox {
                        size = "small",
                        tooltip = LOC "$$$/ML/ExportManager/TTDebugBddb=plot debug info for bright/dark autodetection (requires octave)",
                        value = bind 'debug_bddb',
                        checked_value = true,
                        unchecked_value = false,
                        enabled = bind 'hasOctave',
                    },
                    f:static_text {
                        text_color = ExecLabelColor,
                        title = "debug-bddb",
                        width = share 'labelDebugWidth',
                    },
                    f:spacer {
                        width = share 'labelWarning',
                    },
                    f:static_text {
                        text_color = OctaveLabelColor,
                        title = "(requires octave)",
                    }
                },
                f:row {
                    f:spacer {
                        width = share 'labelExecWidth',
                    },
                    f:checkbox {
                        size = "small",
                        tooltip = LOC "$$$/ML/ExportManager/TTDebugWb=show the vectorscope used for white balance (requires octave)",
                        value = bind 'debug_wb',
                        checked_value = true,
                        unchecked_value = false,
                        enabled = bind 'hasOctave',
                    },
                    f:static_text {
                        text_color = ExecLabelColor,
                        title = "debug-wb",
                        width = share 'labelDebugWidth',
                    },
                    f:spacer {
                        width = share 'labelWarning',
                    },
                    f:static_text {
                        text_color = OctaveLabelColor,
                        title = "(requires octave)",
                    }
                },
                f:row {
                    f:spacer {
                        width = share 'labelExecWidth',
                    },
                    f:checkbox {
                        size = "small",
                        tooltip = LOC "$$$/ML/ExportManager/TTDebugIsoCurve=plot the curve fitting results for ISO and black offset (requires octave)",
                        value = bind 'plot_iso_curve',
                        checked_value = true,
                        unchecked_value = false,
                        enabled = bind 'hasOctave',
                    },
                    f:static_text {
                        text_color = ExecLabelColor,
                        title = "iso-curve",
                        width = share 'labelDebugWidth',
                    },
                    f:spacer {
                        width = share 'labelWarning',
                    },
                    f:static_text {
                        text_color = OctaveLabelColor,
                        title = "(requires octave)",
                    }
                },
                f:row {
                    f:spacer {
                        width = share 'labelExecWidth',
                    },
                    f:checkbox {
                        size = "small",
                        tooltip = LOC "$$$/ML/ExportManager/TTDebugMixCurve=plot the curve used for half-res blending (requires octave)",
                        value = bind 'plot_mix_curve',
                        checked_value = true,
                        unchecked_value = false,
                        enabled = bind 'hasOctave',
                    },
                    f:static_text {
                        text_color = ExecLabelColor,
                        title = "mix-curve",
                        width = share 'labelDebugWidth',
                    },
                    f:spacer {
                        width = share 'labelWarning',
                    },
                    f:static_text {
                        text_color = OctaveLabelColor,
                        title = "(requires octave)",
                    }
                },
                f:row {
                    f:spacer {
                        width = share 'labelExecWidth',
                    },
                    f:checkbox {
                        size = "small",
                        tooltip = LOC "$$$/ML/ExportManager/TTDebugFullresCurve=plot the curve used for full-res blending (requires octave)",
                        value = bind 'plot_fullres_curve',
                        checked_value = true,
                        unchecked_value = false,
                        enabled = bind 'hasOctave',
                    },
                    f:static_text {
                        text_color = ExecLabelColor,
                        title = "fullres-curve",
                        width = share 'labelDebugWidth',
                    },
                    f:spacer {
                        width = share 'labelWarning',
                    },
                    f:static_text {
                        text_color = OctaveLabelColor,
                        title = "(requires octave)",
                    }
                },
            }
        }
    },

    f:row{
        f:push_button {
            title = LOC "$$$/ML/ExportManager/ExecRestore=Restore to default",
            action = function()
                MLDialogs.ResetExec(propertyTable)
            end
        }
    },
}
local sectionExport = {
    title = LOC "$$$/ML/ExportManager/FETitle=File export",
    synopsis = bind 'synopsis_export',
    visible = true,
    f:column {
        spacing = f:control_spacing(),
        fill_horizontal = 1,
        f:row {
            f:static_text {
                width = share 'labelWidth',
                title = LOC "$$$/ML/ExportManager/ASSuffix=Suffix for output Dual ISO file :",
                alignment = labelAlignment,
                size = labelSize,
            },
            f:static_text {
                size = "small",
                text_color = ExecLabelColor,
                title = "IMG_1234-",
            },
            f:edit_field {
                value = bind 'suffix',
                width = 100,
                text_color = ExecLabelColor,
            },
            f:static_text {
                size = "small",
                text_color = ExecLabelColor,
                title = ".dng",
            },
        },
        f:row {
            f:static_text {
                width = share 'labelWidth',
                title = LOC "$$$/ML/ExportManager/ASSubfolder=Add the converted file to this subfolder :",
                alignment = labelAlignment,
                size = labelSize,
            },
            f:edit_field {
                value = bind 'subfolder',
                width = 150,
                placeholder_string = LOC "$$$/ML/ExportManager/ASSubfolderPL=Parent",
                text_color = ExecLabelColor,
                tooltip = LOC "$$$/ML/ExportManager/ASSubfolderInfo=leave blank to reimport into the same folder",
            },
        },
        f:row {
            f:spacer {
                width = share 'labelWidth',
            },
            f:checkbox {
                size = "small",
                value = bind 'showSummary',
                checked_value = true,
                unchecked_value = false,
                tooltip = LOC "$$$/ML/ExportManager/ASSummaryInfo=Uncheck to hide",
            },
            f:static_text {
                title = LOC "$$$/ML/ExportManager/ASSummary=Show summary message after conversion ?",
                alignment = labelAlignment,
                size = labelSize,
            },
        },
        f:row {
            f:spacer {
                width = share 'labelWidth',
            },
            f:checkbox {
                size = "small",
                value = bind 'saveOutput',
                checked_value = true,
                unchecked_value = false,
                tooltip = LOC "$$$/ML/ExportManager/ASLogInfo=Uncheck to remove",
            },
            f:static_text {
                title = LOC "$$$/ML/ExportManager/ASLog=Keep log file after conversion ?",
                alignment = labelAlignment,
                size = labelSize,
            },
        },
        f:row {
            f:spacer {
                width = share 'labelWidth',
            },
            f:checkbox {
                size = "small",
                value = bind 'keepOriginalDNG',
                checked_value = true,
                unchecked_value = false,
                tooltip = LOC "$$$/ML/ExportManager/ASKeepOriginalDNGInfo=Uncheck to overwrite it (affect only DNG file not CR2)",
            },
            f:static_text {
                title = LOC "$$$/ML/ExportManager/ASKeepOriginalDNG=Keep original DNG file after conversion",
                alignment = labelAlignment,
                size = labelSize,
            },
        }
    },
    f:row{
        f:push_button {
            title = LOC "$$$/ML/ExportManager/ExecRestore=Restore to default",
            action = function()
                MLDialogs.ResetExport(propertyTable)
            end
        }
    },
}
local sectionMetadata = {
    title = LOC "$$$/ML/ExportManager/MDTitle=Metadata",
    synopsis = bind 'synopsis_metadata',
    visible = true,
    f:column {
        spacing = f:control_spacing(),
        fill_horizontal = 1,
        f:row {
            f:static_text {
                width = share 'labelWidth',
                title = LOC "$$$/ML/ExportManager/Keywords=Add keywords :",
                alignment = labelAlignment,
                size = labelSize,
            },
            f:static_text {
                size = "small",
                text_color = ExecLabelColor,
                title = "Dual-ISO,",
            },
            f:edit_field {
                value = bind 'keywords',
                width = 150,
                placeholder_string = "cr2hdr, ...",
                tooltip = LOC "$$$/ML/ExportManager/KeywordsInfo=comma-separated",
            },
        },
        f:row {
            f:static_text {
                width = share 'labelWidth',
                title = LOC "$$$/ML/ExportManager/ASLabel=Define the color label for Dual ISO file :",
                alignment = labelAlignment,
                size = labelSize,
            },
            f:popup_menu {
                items = bind 'labels',
                value = bind "label",
                size = 'small',
                tooltip = LOC "$$$/ML/ExportManager/ASLabelInfo=Leave blank to not add color label",
            },
        },
        f:row {
            f:static_text {
                width = share 'labelWidth',
                title = LOC "$$$/ML/ExportManager/ASStaring=Rate converted picture:",
                alignment = labelAlignment,
                size = labelSize,
            },
            f:slider {
                value = bind {
                    key = 'rating',
                    transform = function(value, fromModel)
                        stars = string.rep("*", value)
                        propertyTable.ratingLabel = string.format("%i %s", value, stars)
                        return value
                    end,
                },
                min = 0,
                max = 5,
                integral = true
            },
            f:static_text {
                text_color = ExecLabelColor,
                title = bind 'ratingLabel',
                width = share 'labelWidth',
            },
        },
        f:row {
            f:spacer {
                width = share 'labelWidth',
            },
            f:checkbox {
                size = "small",
                value = bind 'sync_keywords',
                tooltip = LOC "$$$/ML/ExportManager/ASKeywordsSyncInfo=Useful when keywords are added at importation",
                checked_value = true,
                unchecked_value = false,
            },
            f:static_text {
                title = LOC "$$$/ML/ExportManager/ASKeywordsSync=Sync keywords from original picture ?",
                alignment = labelAlignment,
                size = labelSize,
            },
        },
        f:row {
            f:spacer {
                width = share 'labelWidth',
            },
            f:checkbox {
                size = "small",
                value = bind 'syncDevelopParams',
                tooltip = LOC "$$$/ML/ExportManager/ASSyncDevelopParamsInfo=Useful when a develop preset is added at importation",
                checked_value = true,
                unchecked_value = false,
            },
            f:static_text {
                title = LOC "$$$/ML/ExportManager/ASSyncDevelopParams=Sync develop params from original picture ?",
                alignment = labelAlignment,
                size = labelSize,
            },
        },
        f:row {
            f:spacer {
                width = share 'labelWidth',
            },
            f:checkbox {
                size = "small",
                value = bind 'flag',
                tooltip = LOC "$$$/ML/ExportManager/ASFlagInfo=Uncheck to keep the flag 'not set'",
                checked_value = true,
                unchecked_value = false,
            },
            f:static_text {
                title = LOC "$$$/ML/ExportManager/ASFlag=Set the original photo's flag to rejected ?",
                alignment = labelAlignment,
                size = labelSize,
            },
        },
        f:row {
            f:spacer {
                width = share 'labelWidth',
            },
            f:checkbox {
                size = "small",
                text_color = ExecLabelColor,
                value = bind 'addToCollection',
                tooltip = LOC "$$$/ML/ExportManager/ASCollectionInfo=Uncheck to not add to the original picture collection",
                checked_value = true,
                unchecked_value = false,
            },
            f:static_text {
                title = LOC "$$$/ML/ExportManager/ASCollection=Add Dual ISO file to collection ?",
                alignment = labelAlignment,
                size = labelSize,
            },
        },
    },
    f:row{
        f:push_button {
            title = LOC "$$$/ML/ExportManager/ExecRestore=Restore to default",
            action = function()
                MLDialogs.ResetMetadata(propertyTable)
            end
        }
    },
}

local sections = {}
table.insert(sections, sectionTitle)
table.insert(sections, sectionExport)
table.insert(sections, sectionMetadata)
table.insert(sections, sectionExec)

return sections

end

return MLDialogs
