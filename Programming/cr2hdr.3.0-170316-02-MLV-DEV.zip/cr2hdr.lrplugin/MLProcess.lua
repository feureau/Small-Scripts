--[[

    cr2hdr.lrplugin is a plugin for Adobe Photoshop Lightroom
    to convert Dual ISO picture from Magic Lantern.
    http://www.magiclantern.fm/forum/index.php?topic=7139.0

    Copyright (C) <2015> <Christophe Francey kichetof@gmail.com>

    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License
    as published by the Free Software Foundation; either version 2
    of the License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

]]--

local LrApplication = import 'LrApplication'
local LrColor = import 'LrColor'
local LrDialogs = import 'LrDialogs'
local LrErrors = import 'LrErrors'
local LrExportSession = import 'LrExportSession'
local LrFileUtils = import 'LrFileUtils'
local LrFunctionContext = import 'LrFunctionContext'
local LrHttp = import 'LrHttp'
local LrLogger = import 'LrLogger'
local LrPathUtils = import 'LrPathUtils'
local LrProgressScope = import 'LrProgressScope'
--local LrSelection = import 'LrSelection'
local LrTasks = import 'LrTasks'
local LrView = import 'LrView'

local MLProcess = {}

local helpers = require 'helpers'

local LRversion = LrApplication.versionTable()
MLProcess.LRv = LRversion["major"]

MLProcess.binPath = LrPathUtils.child(_PLUGIN.path, 'bin')

-- Check for Mac/Win dcraw and exiftool dependencies
function MLProcess.checkDependencies()
    local cmd = WIN_ENV and 'dir /b "%s\\dcraw.exe" && dir /b "%s\\exiftool.exe"' or 'exec ls "%s/dcraw" && ls "%s/exiftool"'
    cmd = string.format(cmd, MLProcess.binPath, MLProcess.binPath)
    return LrTasks.execute(cmd) == 0 and true or false
end

-- Export new PATH before running command
function MLProcess.addPathToCommand(cmd)
    if MAC_ENV then
        return 'export PATH="' .. MLProcess.binPath .. '":${PATH} && ' .. cmd
    else
        return cmd
    end
end

-- Fill empty table for summary message
function MLProcess.checkTab (tab, err)
    local msg = err ~= 1 and LOC "$$$/ML/Publish/Finish/NoImage=No image" or LOC "$$$/ML/Publish/Finish/NoError=No error"
    return #tab == 0 and table.insert(tab, { ["title"] = msg, ["value"] = "" }) or tab
end

-- Create all subdirectories before returning the child
function MLProcess.getSubfolderPath(path, subfolder)
    local filename = LrPathUtils.leafName(path)
    local pathNofilename = LrPathUtils.parent(path)
    local newPath = LrPathUtils.child(pathNofilename, subfolder)
    LrFileUtils.createAllDirectories(newPath)
    return LrPathUtils.child(newPath, filename)
end

-- Add suffix to final file
function MLProcess.getRenamePath(path, suffix)
    local pathNoExt = LrPathUtils.removeExtension(path)
    local ext = LrPathUtils.extension(path)
    local finalPath = string.format("%s-%s", pathNoExt, suffix)
    return LrPathUtils.addExtension(finalPath, ext)
end

-- Try to move file to subfolder
function MLProcess.moveToSubFolder(destPath, subFolder)
    local finalSubfolderPath = MLProcess.getSubfolderPath(destPath, subFolder)
    mlLog:debugf("subfolder: %s", finalSubfolderPath)
    if not LrFileUtils.move(destPath, finalSubfolderPath) then
        return false, destPath
    else
        return true, finalSubfolderPath
    end
end

-- return only value of table
function MLProcess.listIterator(t)
    local i = 0
    local n = #t
    return function ()
        i = i + 1
        if i <= n then return t[i] end
    end
end

-- generate cr2hdr args
function MLProcess.generateArgs(exportSettings)

    local args = string.format('%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s',
        exportSettings.shortcut_fast == true and " --fast" or "",
        exportSettings.interp_method == 0 and " --amaze-edge" or " --mean23",
        exportSettings.chroma_smooth_method == 0 and " --no-cs" or string.format(" --cs%dx%d", exportSettings.chroma_smooth_method, exportSettings.chroma_smooth_method),
        exportSettings.fix_bad_pixels == 0 and " --no-bad-pix" or ((exportSettings.fix_bad_pixels == 1) and " --bad-pix" or " --really-bad-pix"),
        exportSettings.debug_bad_pixels == true and " --black-bad-pix" or "",
        exportSettings.use_fullres == 0 and " --no-fullres" or " --fullres",
        exportSettings.use_alias_map == 0 and " --no-alias-map" or " --alias-map",
        exportSettings.use_stripe_fix == 0 and " --no-stripe-fix" or " --stripe-fix",
        exportSettings.compress == 1 and " --compress" or ((exportSettings.compress == 2) and " --compress-lossy" or ""),
        exportSettings.debug_blend == true and " --debug-blend" or "",
        exportSettings.debug_black == true and " --debug-black" or "",
        exportSettings.debug_amaze == true and " --debug-amaze" or "",
        exportSettings.debug_edge == true and " --debug-edge" or "",
        exportSettings.debug_alias == true and " --debug-alias" or "",
        exportSettings.plot_iso_curve == true and " --iso-curve" or "",
        exportSettings.plot_mix_curve == true and " --mix-curve" or "",
        exportSettings.plot_fullres_curve == true and " --fullres-curve" or "",
        exportSettings.soft_film > 0 and string.format(" --soft-film=%.1f", exportSettings.soft_film) or "",
        exportSettings.gray_wb == 0 and " --wb=graymax" or exportSettings.gray_wb == 1 and " --wb=graymed" or exportSettings.gray_wb == 2 and " --wb=exif" or "",
        exportSettings.same_levels ~= 0 and " --same-levels" or "",
        exportSettings.skip_existing == true and " --skip-existing" or "",
        exportSettings.embed_original == true and " --embed-original-copy" or "",
        exportSettings.debug_rggb == true and " --debug-rggb" or "",
        exportSettings.debug_bddb == true and " --debug-bddb" or "",
        exportSettings.debug_wb == true and " --debug-wb" or ""
        )

    mlLog:debugf("arguments : %s", args)
    return args
end

-- Return command line for cr2hdr
function MLProcess.generateCmd(exportSettings, pluginPath, filePath, output, args)

    local exec = "cr2hdr"
    local gt = " > "
    local cmd = WIN_ENV and 'start /D "%s\\bin" /B /WAIT /BELOWNORMAL %s.exe%s %s' or 'exec "%s/bin/%s"%s %s'
    local log = '%s%s"%s"'
    local escape = WIN_ENV and '"%s"' or '%s'

    local finalCmd = string.format(escape,
        string.format(log,
            string.format(cmd,
                pluginPath,
                exec,
                args,
                filePath
            ),
            gt,
            output)
    )
    return MLProcess.addPathToCommand(finalCmd)
end

-- remove trailing and leading spaces
function MLProcess.trim(s)
    return (s:gsub("^%s*(.-)%s*$", "%1"))
end

-- split string with user pattern and return array
function MLProcess.split(myString, inSplitPattern, outResults)

    if not outResults then
        outResults = { }
    end

    local theStart = 1
    local theSplitStart, theSplitEnd = string.find(myString, inSplitPattern, theStart)

    while theSplitStart do
        table.insert( outResults, string.sub( myString, theStart, theSplitStart-1 ) )
        theStart = theSplitEnd + 1
        theSplitStart, theSplitEnd = string.find( myString, inSplitPattern, theStart )
    end

    table.insert(outResults, string.sub(myString, theStart))
    return outResults
end

-- check file format DNG and suffix null
function MLProcess.checkDngExtSuffix(photo, suffix)
    if photo:getRawMetadata("fileFormat") == "DNG" and suffix == "" then
        return true
    else
        return false
    end
end

-- check if keyword exists for this photo
function MLProcess.checkKeyword(photo, keyword)
    local keywords = photo:getRawMetadata("keywords")
    for i, key in ipairs(keywords) do
        if key:getName() == keyword then
            return true
        end
    end
    return false
end

-- import DualISO converted image to catalog
function MLProcess.importDualIsoConverted(catalog, photo, originalFilePath, finalPathDNG, finalPathTXT, exportSettings, args, metadata)
    local originalCollection = photo:getContainedCollections()
    local importDualiso = catalog:withWriteAccessDo('Import from ML DualISO', function(context)
            local photoImported
            if string.lower(finalPathDNG) == string.lower(photo:getRawMetadata("path")) then
                photoImported = catalog:findPhotoByPath(finalPathDNG)
            else
                photoImported = catalog:addPhoto(finalPathDNG, photo, 'above')
            end

            if exportSettings.label ~= "none" then
                photoImported:setRawMetadata('label', exportSettings.label)
            end
            
            if exportSettings.rating > 0 then
                photoImported:setRawMetadata('rating', exportSettings.rating)
            end

            if exportSettings.keywords ~= '' then
                local keywords = MLProcess.split(exportSettings.keywords, ",")
                local keyword
                for i, key in ipairs (keywords) do
                    key = MLProcess.trim(key)
                    if key ~= "" then
                        keyword = catalog:createKeyword(key, nil, true, nil, true)
                        photoImported:addKeyword(keyword)
                    end
                end
            end

            -- sync keywords from original picture
            if exportSettings.sync_keywords and MLProcess.checkDngExtSuffix(photo, exportSettings.suffix) == false then
                local keywords = photo:getRawMetadata("keywords")
                for i, key in ipairs(keywords) do
                    if key:getName() ~= "Dual-ISO raw" then
                        photoImported:addKeyword(key)
                    end
                end
            end

            MLProcess.fillMetadata(photoImported, metadata[LrPathUtils.leafName(originalFilePath)])

            local cr2hdrExec = "cr2hdr"
            photoImported:setPropertyForPlugin (_PLUGIN, 'cr2hdrExec', cr2hdrExec)
            photoImported:setPropertyForPlugin (_PLUGIN, 'cr2hdrArgs', args)

            if exportSettings.addToCollection and next(originalCollection) ~= nil then
                for k, v in pairs(originalCollection) do
                    v:addPhotos({ photoImported })
                end
            end

            if exportSettings.saveOutput == false and exportSettings.same_levels == 0 then
                LrFileUtils.moveToTrash(finalPathTXT)
            end

            if MLProcess.checkDngExtSuffix(photo, exportSettings.suffix) == false then
                if exportSettings.flag == true then
                    photo:setRawMetadata('pickStatus', -1)
                end
                -- Add a keyword to original picture to simplify identification Dual-ISO raw / no Dual-ISO
                keyword = catalog:createKeyword("Dual-ISO raw", nil, true, nil, true)
                photo:addKeyword(keyword)
            end

            if MLProcess.LRv >= 6 and exportSettings.syncDevelopParams then
                local syncParams = photo:getDevelopSettings()
                photoImported:createDevelopSnapshot("Before syncing Dual ISO raw params", true)
                photoImported:applyDevelopSettings(syncParams) -- see https://forums.adobe.com/message/8096706#8096706
            end

        end,
        {timeout = 30}
    )

    if importDualiso ~= "executed" then
        return false
    else
        return true
    end
end

-- process user settings before import into catalog
function MLProcess.dualIsoProcess(catalog, photo, originalFilePath, finalPathDNG, finalPathTXT, summary, exportSettings, args)

    local metadata = MLProcess.parseLogFileToArray(finalPathTXT)
    local fileFormat = string.lower(photo:getRawMetadata("fileFormat"))

    if metadata[LrPathUtils.leafName(originalFilePath)]["No Dual ISO"] == false then
        if not exportSettings.keepOriginalDNG and exportSettings.suffix ~= "" then
            local finalPath = MLProcess.getRenamePath(finalPathDNG, exportSettings.suffix)
            local finalPathLog = MLProcess.getRenamePath(finalPathTXT, exportSettings.suffix)
            if LrFileUtils.exists(finalPath) then
                finalPath = LrFileUtils.chooseUniqueFileName(finalPath)
                finalPathLog = LrFileUtils.chooseUniqueFileName(finalPathLog)
            end
            mlLog:debugf("finalPath: %s", finalPath)
            local moveLogFile = LrFileUtils.move(finalPathTXT, finalPathLog) -- don't check if move success, bypass problem with --same-levels
            finalPathTXT = finalPathLog
            if LrFileUtils.move(finalPathDNG, finalPath) == false then
                summary.errorMsg[#summary.errorMsg+1] = { ["title"] = LOC("$$$/ML/Import/ErrorSuffix=Unable to add suffix ^1 to file ^2", exportSettings.suffix, LrPathUtils.leafName(finalPathDNG)), ["value"] = "" }
            else
                finalPathDNG = finalPath
            end
        end

        -- after cr2hdr, move file to subfolder
        if exportSettings.subfolder ~= "" then
            finalPathDNGError, finalPathDNG = MLProcess.moveToSubFolder(finalPathDNG, exportSettings.subfolder)
            finalPathTXTError, finalPathTXT = MLProcess.moveToSubFolder(finalPathTXT, exportSettings.subfolder)

            if finalPathDNGError == false then
                summary.errorMsg[#summary.errorMsg+1] = { ["title"] = LOC("$$$/ML/Import/ErrorSubfolder=Unable to move ^1 to subfolder ^2", LrPathUtils.leafName(finalPathDNG), exportSettings.subfolder), ["value"] = "" }
            end
        end

        local import = MLProcess.importDualIsoConverted(catalog, photo, originalFilePath, finalPathDNG, finalPathTXT, exportSettings, args, metadata)
        if import == true then
            summary.success[#summary.success+1] = { ["title"] = LrPathUtils.leafName(originalFilePath), ["value"] = "" }
        else
            summary.errorMsg[#summary.errorMsg+1] = { ["title"] = LOC "$$$/ML/Import/Error=Unable to import the Dual ISO file!^n^nPlease manually synchronise your folder", ["value"] = "" }
        end
    else
        local importDualiso = catalog:withWriteAccessDo('Import from ML DualISO', function(context)
                -- Add a keyword to original picture to simplify identification Dual-ISO raw / no Dual-ISO
                keyword = catalog:createKeyword("no Dual-ISO", nil, true, nil, true)
                photo:addKeyword(keyword)
            end,
            {timeout = 30}
        )
        LrFileUtils.moveToTrash(finalPathTXT)
        if LrFileUtils.exists(finalPathDNG) and string.lower(finalPathDNG) ~= string.lower(photo:getRawMetadata("path")) then
            LrFileUtils.moveToTrash(finalPathDNG)
        end
        summary.nodual[#summary.nodual+1] = { ["title"] = LrPathUtils.leafName(originalFilePath), ["value"] = "" }
    end
end

-- parse logfile to read info
function MLProcess.parseLogFileToArray(filename)

    local logFileOpen = assert(io.open(filename, 'r'))
    local logfile = logFileOpen:read("*all")
    logFileOpen:close()

    local info = {}
    local info_index = {}
    local masterKey = "none"
    local version = ""
    for line in logfile:gmatch("[^\r\n]+") do
        if line:match('%s*([%w%s-]+)%s*:%s*([%S ]+)%s*') then
            for k, v in line:gmatch('%s*([%w%s-]+)%s*:%s*([%S ]+)%s*') do
                k = MLProcess.trim(k)
                -- keep input file to store in master keys
                if k == "Input file" then
                    masterKey = LrPathUtils.leafName(MLProcess.trim(v))
                end

                if k == "Last update" then
                    version = MLProcess.trim(v)
                end

                if info[masterKey] == nil then
                    info[masterKey] = {}
                    info[masterKey]["No Dual ISO"] = false
                    info_index[masterKey] = {}
                end

                -- there are duplicating keys in output (for instance, "Dynamic range")
                if info[masterKey][k] ~= nil then
                    local t = k
                    info_index[masterKey][t] = info_index[masterKey][t] + 1
                    k = k .. info_index[masterKey][t]
                else
                    info_index[masterKey][k] = 1
                end

                info[masterKey][k] = MLProcess.trim(v)

                if version ~= "" and info[masterKey]['Last update'] == nil then
                    info[masterKey]["Last update"] = version
                end

            end
        elseif line == "Doesn't look like interlaced ISO" then
            info[masterKey]["No Dual ISO"] = true
        end
    end

    return info
end

-- fill metadata
function MLProcess.fillMetadata(photo, meta)

    -- exit function if metadata array is empty
    if meta == nil then
        do return end
    end

    local metaString1
    local metaString2

    if meta['ISO difference'] ~= nil then
        metaString1 = meta['ISO difference']:match("(%S+) EV")
        local isoFirst = photo:getRawMetadata("isoSpeedRating")
        if isoFirst ~= nil then
            local isoRange = string.format("%s - %s", isoFirst, 2^math.floor(metaString1+0.5)*isoFirst)
            photo:setPropertyForPlugin (_PLUGIN, 'cr2hdrISORange', isoRange)
        end
        metaString1 = string.format("%s EV", metaString1)
        photo:setPropertyForPlugin (_PLUGIN, 'ISOdifference', metaString1)
    end

    if meta['Dynamic range2'] ~= nil then
        metaString1 = meta['Dynamic range2']:match("(%S+ EV)")
        photo:setPropertyForPlugin (_PLUGIN, 'DynamicRange', metaString1)
    end

    if meta['Dynamic range'] ~= nil then
        metaString1, metaString2 = meta['Dynamic range']:match("(%S+) %(%+%) (%S+)")
        photo:setPropertyForPlugin (_PLUGIN, 'DynamicRangeOrig1', metaString1 .. ' EV')
        photo:setPropertyForPlugin (_PLUGIN, 'DynamicRangeOrig2', metaString2 .. ' EV')
    end

    if meta['Semi-overexposed'] ~= nil then
        metaString1 = meta['Semi-overexposed']:match("(%S+%%)")
        photo:setPropertyForPlugin (_PLUGIN, 'SemiOverexposed', metaString1)
    end

    if meta['Deep shadows'] ~= nil then
        metaString1 = meta['Deep shadows']:match("(%S+%%)")
        photo:setPropertyForPlugin (_PLUGIN, 'DeepShadows', metaString1)
    end

    if meta['Noise level'] ~= nil then
        metaString1, metaString2 = meta['Noise level']:match("(%S+) .+, ideally (%S+)")
        photo:setPropertyForPlugin (_PLUGIN, 'NoiseLevel', metaString1)
        photo:setPropertyForPlugin (_PLUGIN, 'NoiseLevelIdeal', metaString2)
    end

    if meta['ISO overlap'] ~= nil then
        metaString1 = meta['ISO overlap']:match("(%S+ EV)")
        photo:setPropertyForPlugin (_PLUGIN, 'ISOoverlap', metaString1)
    end

    if meta['Last update'] ~= nil then
        metaString1, metaString2 = meta['Last update']:match("(%S+) on (%S+)")
        local lastUpd = string.format("%s (%s)", metaString2, metaString1)
        photo:setPropertyForPlugin(_PLUGIN, 'cr2hdrVersion', lastUpd)
    end
end

-- process global after user click to export
function MLProcess.process(functionContext, exportContext)
    local startTime = os.time()
    
    -- var for summary message
    local summary = {
        ["success"] = {},
        ["nodual"] = {},
        ['dual'] = {},
        ['format'] = {},
        ["fail"] = {},
        ["errorMsg"] = {}
    }
    functionContext:addCleanupHandler(
        function(status, message)
            if not status then
                  --LrDialogs.message("~ There has been an error ~", string.format("Please report the problem to Magic Lantern forum\n\n%s", message), "critical")
            end
        end
    )

    if MLProcess.checkDependencies() == false then
        LrDialogs.message(LOC "$$$/ML/Dependencies/ErrorTitle=~ Dependencies error ~", LOC "$$$/ML/Dpendencies/Error=This plugin (cr2hdr) need dcraw and exiftool.^n^nPlease install it before run this plugin")
        do return end
    end

    local catalog = LrApplication:activeCatalog()
    local pluginPath = _PLUGIN.path
    local exportSession = exportContext.exportSession
    local photosToRendering = ""
    local exportSettings = exportContext.propertyTable
    local nPhotos = exportSession:countRenditions()
    local progressScope = exportContext:configureProgress {
        title = nPhotos > 1 and LOC("$$$/ML/Publish/Progress=Exporting ^1 photos to cr2hdr", nPhotos) or LOC "$$$/ML/Publish/Progress/One=Exporting one photo to cr2hdr",
    }
    local i = 0
    local firstFilePath = ""
    local sameLevelsPath = ""
    local sameLevelsPathAll = ""
    local lastFilePathName = ""

    for photo in exportSession:photosToExport() do
        i = i + 1
        local originalFilePath = photo:getRawMetadata("path")
        local fileFormat = photo:getRawMetadata("fileFormat")

        local testDualIsoKeyword = MLProcess.checkKeyword(photo, "Dual-ISO")
        local testNoDualIsoKeyword = MLProcess.checkKeyword(photo, "no Dual-ISO")

        if photo:checkPhotoAvailability() and (fileFormat == "RAW" or fileFormat == "DNG") and testDualIsoKeyword == false and testNoDualIsoKeyword == false then
            --if exportSettings.same_levels ~= 2 then
                if fileFormat == "DNG" and exportSettings.suffix ~= "" and exportSettings.keepOriginalDNG then
                    local newOriginalFilePath = MLProcess.getRenamePath(originalFilePath, exportSettings.suffix)
                    if LrFileUtils.exists(newOriginalFilePath) then
                        newOriginalFilePath = LrFileUtils.chooseUniqueFileName(newOriginalFilePath)
                    end
                    if LrFileUtils.copy(originalFilePath, newOriginalFilePath) then
                        originalFilePath = newOriginalFilePath
                    end
                end

                local finalPathDNG = LrPathUtils.replaceExtension(originalFilePath, "DNG")
                local finalPathTXT = LrPathUtils.replaceExtension(originalFilePath, "TXT")
                mlLog:debugf("Path: %s", originalFilePath)
                mlLog:debugf("Path DNG: %s", finalPathDNG)
                mlLog:debugf("Path TXT: %s", finalPathTXT)

                -- use for --same-levels "classic"
                if i == 1 then
                    firstFilePath = LrPathUtils.removeExtension(finalPathTXT)
                    mlLog:debugf("first: %s", firstFilePath)
                end

                photosToRendering = string.format("%s \"%s\"", photosToRendering, originalFilePath)
                if i == nPhotos then
                    lastFilePathName = LrPathUtils.replaceExtension(LrPathUtils.leafName(photo:getRawMetadata("path")), "TXT")
                end

                -- use for --same-levels "entire path"
                if sameLevelsPath ~= nil then
                    sameLevelsPath = LrPathUtils.parent(photo:getRawMetadata("path"))
                end
            
                mlLog:debugf("sameLevelsPath %s", sameLevelsPath)
                if exportSettings.same_levels == 0 then
                    progressScope:setPortionComplete((i - 1) / nPhotos)
                    local args = MLProcess.generateArgs(exportSettings)
                    local command = MLProcess.generateCmd(exportSettings, pluginPath, string.format("\"%s\"", originalFilePath), finalPathTXT, args)
                    mlLog:debugf("command : %s", command)

                    result = LrTasks.execute(command)

                    if result == 0 then

                        if exportSettings.gray_wb == 3 then
                            local cmd = ""
                            if WIN_ENV then
                                cmd = 'for /F "tokens=3-6" ##a in (\'%s\\dcraw.exe -i -v "%s" ^| findstr /C:"Camera multipliers"\') do (for /F ##m in (\'powershell ##b/##a\') do set res1=##m & for /F ##n in (\'powershell ##d/##c\') do set res2=##n) & %s\\exiftool.exe "-AsShotNeutral=##res1:,=.## 1 ##res2:,=.##" "%s"'
                                cmd = string.format(cmd, MLProcess.binPath, originalFilePath, MLProcess.binPath, finalPathDNG)
                                cmd = string.gsub(cmd, "##", "%%")
                            else
                                cmd = '"%s/exiftool" "-AsShotNeutral=$(%s/dcraw -i -v "%s" | awk \'/Camera multipliers/ { print $4/$3}\') 1 $(%s/dcraw -i -v "%s" | awk \'/Camera multipliers/ { print $6/$5}\')" "%s"'
                                cmd = string.format(cmd, MLProcess.binPath, MLProcess.binPath, originalFilePath, MLProcess.binPath, originalFilePath, finalPathDNG)
                            end
                            mlLog:debugf("wb=dcraw cmd %s", cmd)
                            wb_restult = LrTasks.execute(cmd)
                        end

                        MLProcess.dualIsoProcess(catalog, photo, originalFilePath, finalPathDNG, finalPathTXT, summary, exportSettings, args)
                    else
                        summary.errorMsg[#summary.errorMsg+1] =  { ["title"] = LOC("$$$/ML/Publish/Error=Unable to export ^1 to cr2hdr! Error ^2", originalFilePath, result), ["value"] = "" }
                        break
                    end
                end

            --else
                -- use for --same-levels "entire path"
                --sameLevelsPath = LrPathUtils.parent(photo:getRawMetadata("path"))
            --end
        else
            
            sameLevelsPath = nil
            
            if photo:checkPhotoAvailability() == false then
                summary.errorMsg[#summary.errorMsg+1] =  { ["title"] = LOC("$$$/ML/Publish/PhotoAvailabilityError=Photo ^1 are not present on the disk", LrPathUtils.leafName(originalFilePath)), ["value"] = "" }
            elseif testDualIsoKeyword == true then
                summary.dual[#summary.dual+1] = { ["title"] = LrPathUtils.leafName(originalFilePath), ["value"] = "" }
            elseif testNoDualIsoKeyword == true then
                summary.nodual[#summary.nodual+1] = { ["title"] = LrPathUtils.leafName(originalFilePath), ["value"] = "" }
            else
                summary.format[#summary.format+1] = { ["title"] = LrPathUtils.leafName(originalFilePath), ["value"] = "" }
            end
        end
    end

    if exportSettings.same_levels ~= 0 and sameLevelsPath ~= nil then
        progressScope:setPortionComplete(0)

        if exportSettings.same_levels == 1 then
            finalPathTXT = string.format("%s-%s", firstFilePath, lastFilePathName)
            filePath = MLProcess.trim(photosToRendering)
            photosToExportArray = exportSession:photosToExport()
        end
        if exportSettings.same_levels == 2 then
            finalPathTXT = LrPathUtils.child(sameLevelsPath, LrPathUtils.leafName(sameLevelsPath) .. ".TXT")
            --[[
            if exportSettings.suffix ~= "" and exportSettings.keepOriginalDNG then
                --filePath = string.format("\"%s/\"*-%s.CR2 \"%s/\"*-%s.DNG", sameLevelsPath, exportSettings.suffix, sameLevelsPath, exportSettings.suffix)
                filePath = string.format('"%s\\"*-%s.CR2 "%s\\"*-%s.DNG', sameLevelsPath, exportSettings.suffix, sameLevelsPath, exportSettings.suffix)
            else
                --filePath = string.format("\"%s/\"*.CR2 \"%s/\"*.DNG", sameLevelsPath, sameLevelsPath)
                filePath = string.format('"%s/*.CR2" "%s/*.DNG"', sameLevelsPath, sameLevelsPath)
            end
            ]]
            if MAC_ENV then
                filePath = string.format('"%s/"*.CR2 "%s/"*.DNG', sameLevelsPath, sameLevelsPath)
            else
                filePath = string.format('"%s\\"*.CR2 "%s\\"*.DNG', sameLevelsPath, sameLevelsPath) -- Need to be tested
            end
            
            local finalFolder = catalog:getFolderByPath(sameLevelsPath)
            photosToExportArray = MLProcess.listIterator(finalFolder:getPhotos(false))
        end

        local args = MLProcess.generateArgs(exportSettings)
        local command = MLProcess.generateCmd(exportSettings, pluginPath, filePath, finalPathTXT, args)
        mlLog:debugf("command : %s", command)

        result = LrTasks.execute(command)

        if result == 0 then
            mlLog:debug("command status OK")
            for photo in photosToExportArray do
                originalFilePath = photo:getRawMetadata("path")
                finalPathDNG = LrPathUtils.replaceExtension(originalFilePath, "DNG")
                fileFormat = photo:getRawMetadata("fileFormat")
                if fileFormat == "DNG" and exportSettings.suffix ~= "" and exportSettings.keepOriginalDNG then
                    local newFinalPathDNG = MLProcess.getRenamePath(finalPathDNG, exportSettings.suffix)
                    if LrFileUtils.exists(newFinalPathDNG) then
                        -- TODO check if -dualiso exist and -dualiso-X to find latest copy
                        finalPathDNG = newFinalPathDNG
                        originalFilePath = newFinalPathDNG
                    end
                end
                MLProcess.dualIsoProcess(catalog, photo, originalFilePath, finalPathDNG, finalPathTXT, summary, exportSettings, args)
            end
        end

        if exportSettings.saveOutput == false then
            if exportSettings.suffix ~= "" then
                finalPathTXT = MLProcess.getRenamePath(finalPathTXT, exportSettings.suffix)
            end
            if MLProcess.checkDngExtSuffix(photo, exportSettings.suffix) == true then
                finalPathTXT = LrFileUtils.chooseUniqueFileName(finalPathTXT)
            end
            if exportSettings.subfolder ~= "" then
                finalPathTXTError, finalPathTXT = MLProcess.moveToSubFolder(finalPathTXT, exportSettings.subfolder)
            end

            LrFileUtils.moveToTrash(finalPathTXT)
        end
    else
        if exportSettings.same_levels ~= 0 and sameLevelsPath == nil then
            summary.errorMsg[#summary.errorMsg+1] =  { ["title"] = LOC("$$$/ML/Publish/PhotoAvailabilityAndOrKeywordError=Photos are not present on the disk or contains keyword Dual-ISO/No Dual-ISO"), ["value"] = "" }
        end
    end

    progressScope:done()
    
    local endTime = os.time()
    local showTime = helpers.secondsToClock(endTime - startTime)

    -- Show final message
    mlLog:debugf("time: %s - success: %d - nodual: %d - dual: %d - format: %d - fail: %d - errorMsg: %d",
        showTime,
        #summary.success,
        #summary.nodual,
        #summary.dual,
        #summary.format,
        #summary.fail,
        #summary.errorMsg
        )

    if exportSettings.showSummary then

        LrTasks.startAsyncTask(function()

            local v = LrView.osFactory()
            local totalImg = #summary.success
            local margin = 5
            local width = 600

            LrDialogs.presentModalDialog {
                title = LOC "$$$/ML/Publish/Finish=cr2hdr export finished",
                resizable = "vertically",
                cancelVerb = "< exclude >",
                contents = v:view {
                    width = width,
                    v:static_text {
                        width = width,
                        title = totalImg == 0 and LOC "$$$/ML/Publish/NoPhotoExported=No photo has been exported" or totalImg <= 1 and LOC("$$$/ML/Publish/NbPhotoExported=^1 photo has been exported with success in ^2", totalImg, showTime) or LOC("$$$/ML/Publish/NbPhotosExported=^1 photos have been exported with success in ^2", totalImg, showTime),
                        alignment = "center",
                        font = "<system/bold>",
                    },
                    v:spacer {
                        height = 20
                    },
                    v:tab_view {
                        value = "FinishTab1",
                        fill_horizontal = 1,
                        v:tab_view_item {
                            title = LOC("$$$/ML/Publish/Finish/Success=Converted^1", (#summary.success > 0 and " (" .. #summary.success .. ")" or "")),
                            identifier = "FinishTab1",
                            v:simple_list {
                                width = width,
                                items = MLProcess.checkTab(summary.success, 0),
                            },
                        },
                        v:tab_view_item {
                            title = LOC("$$$/ML/Publish/Finish/noDual=No DualISO^1", (#summary.nodual > 0 and " (" .. #summary.nodual .. ")" or "")),
                            identifier = "FinishTab2",
                            v:simple_list {
                                width = width,
                                items = MLProcess.checkTab(summary.nodual, 0),
                            },
                        },
                        v:tab_view_item {
                            title = LOC("$$$/ML/Publish/Finish/AlreadyConvertTitle=Already treated^1", (#summary.dual > 0 and " (" .. #summary.dual .. ")" or "")),
                            identifier = "FinishTab3",
                            v:simple_list {
                                width = width,
                                items = MLProcess.checkTab(summary.dual, 0),
                            },
                        },
                        v:tab_view_item {
                            title = LOC("$$$/ML/Publish/Finish/NotRawTitle=Wrong format^1", (#summary.format > 0 and " (" .. #summary.format .. ")" or "")),
                            identifier = "FinishTab4",
                            v:simple_list {
                                width = width,
                                items = MLProcess.checkTab(summary.format, 0),
                            },
                        },
                        v:tab_view_item {
                            title = LOC("$$$/ML/Publish/Finish/Error=Error^1", (#summary.errorMsg > 0 and " (" .. #summary.errorMsg .. ")" or "")),
                            identifier = "FinishTab5",
                            v:simple_list {
                                width = width,
                                items = MLProcess.checkTab(summary.errorMsg, 1),
                            },
                        },
                    },
                }
            }

        end)

    end

end

return MLProcess
