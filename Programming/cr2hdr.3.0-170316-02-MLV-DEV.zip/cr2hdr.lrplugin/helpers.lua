--[[

    cr2hdr.lrplugin is a plugin for Adobe Photoshop Lightroom
    to convert Dual ISO picture from Magic Lantern.
    http://www.magiclantern.fm/forum/index.php?topic=7139.0

    Copyright (C) <2015> <Christophe Francey kichetof@gmail.com>

    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License
    as published by the Free Software Foundation; either version 2
    of the License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

]]--

local LrFileUtils = import 'LrFileUtils'
local LrPathUtils = import 'LrPathUtils'

local helpers = {}

function helpers.secondsToClock(seconds)
    local time = tonumber(seconds)
    
    if time <= 0 then
        return "00:00:00"
    else
        h = string.format("%02.f", math.floor(time / 3600))
        m = string.format("%02.f", math.floor(time / 60 - (h * 60)))
        s = string.format("%02.f", math.floor(time - h * 3600 - m * 60))
        return h .. ":" .. m .. ":" .. s
    end
end

function helpers.copyExportPreset()
    local lrExportPresetsFolder = LrPathUtils.child(LrPathUtils.getStandardFilePath('appData'), 'Export Presets')
    local mlExportPresetsFoler = LrPathUtils.child(lrExportPresetsFolder, 'Magic Lantern')
    
    local presetName = "cr2hdr.lrtemplate"
    local presetPath = LrPathUtils.child(_PLUGIN.path, 'presets')
    local presetFilePath = LrPathUtils.child(presetPath, presetName)
    
    if not LrFileUtils.exists(mlExportPresetsFoler) then
        LrFileUtils.createAllDirectories(mlExportPresetsFoler)
    end
    
    if LrFileUtils.exists(mlExportPresetsFoler) then
        if LrFileUtils.copy(presetFilePath, LrPathUtils.child(mlExportPresetsFoler, presetName)) then
            --mlLog:debug("preset copied")
            return true
        else
            --mlLog:debug("unable to copy preset")
            return false
        end
    else
        --mlLog:debug("preset already exists")
        return true
    end
    
end

function helpers.copyFilterPresets()
    local lrFilterPresetsFolder = LrPathUtils.child(LrPathUtils.getStandardFilePath('appData'), 'Filter Presets')
    local returnValue
    for filePath in LrFileUtils.files(LrPathUtils.child(_PLUGIN.path, 'Filter Presets')) do
        local filename = LrPathUtils.leafName(filePath)
        if not LrFileUtils.exists(LrPathUtils.child(lrFilterPresetsFolder, filename)) then
            if LrFileUtils.copy(filePath, LrPathUtils.child(lrFilterPresetsFolder, filename)) then
                returnValue = true
                --mlLog:debug("Filter presets copied")
            else
                returnValue = false
                --mlLog:debug("Unable to copy filter presets")
            end
        else
            returnValue = true
            --mlLog:debug("presets already exists")
        end
    end
    return returnValue
end


return helpers