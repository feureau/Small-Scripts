--[[

    cr2hdr.lrplugin is a plugin for Adobe Photoshop Lightroom
    to convert Dual ISO picture from Magic Lantern.
    http://www.magiclantern.fm/forum/index.php?topic=7139.0

    Copyright (C) <2015> <Christophe Francey kichetof@gmail.com>

    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License
    as published by the Free Software Foundation; either version 2
    of the License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

]]--

return {

    title = LOC "$$$/ML/Metadata/TagsetTitle=Dual ISO",
    id = 'DualISOMetadataTagset',

    items = {
        {
            'com.adobe.label',
            label = LOC "$$$/ML/Metadata/TagsetDICTitle=Dual ISO Converter",
        },
        'com.adobe.lightroom.export.ml.dualiso.cr2hdrISORange',
        'com.adobe.lightroom.export.ml.dualiso.ISOdifference',
        'com.adobe.lightroom.export.ml.dualiso.DynamicRange',
        'com.adobe.lightroom.export.ml.dualiso.DynamicRangeOrig1',
        'com.adobe.lightroom.export.ml.dualiso.DynamicRangeOrig2',
        'com.adobe.lightroom.export.ml.dualiso.SemiOverexposed',
        'com.adobe.lightroom.export.ml.dualiso.DeepShadows',
        'com.adobe.lightroom.export.ml.dualiso.ISOoverlap',
        'com.adobe.lightroom.export.ml.dualiso.NoiseLevel',
        'com.adobe.lightroom.export.ml.dualiso.NoiseLevelIdeal',

        'com.adobe.separator',
        {
            'com.adobe.label',
            label = LOC "$$$/ML/Metadata/TagsetCLTitle=Command line"
        },

        'com.adobe.lightroom.export.ml.dualiso.cr2hdrExec',
        'com.adobe.lightroom.export.ml.dualiso.cr2hdrVersion',
        'com.adobe.lightroom.export.ml.dualiso.cr2hdrArgs',
    },

}
