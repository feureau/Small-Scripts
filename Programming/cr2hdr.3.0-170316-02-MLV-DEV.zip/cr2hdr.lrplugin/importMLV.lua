--[[

    cr2hdr.lrplugin is a plugin for Adobe Photoshop Lightroom
    to convert Dual ISO picture from Magic Lantern.
    http://www.magiclantern.fm/forum/index.php?topic=7139.0

    Copyright (C) <2015> <Christophe Francey kichetof@gmail.com>

    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License
    as published by the Free Software Foundation; either version 2
    of the License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

]]--

local LrApplication = import 'LrApplication'
local LrBinding = import 'LrBinding'
local LrColor = import 'LrColor'
local LrDialogs = import 'LrDialogs'
local LrFileUtils = import 'LrFileUtils'
local LrFunctionContext = import 'LrFunctionContext'
local LrLogger = import 'LrLogger'
local LrPathUtils = import 'LrPathUtils'
local LrPrefs = import 'LrPrefs'
local LrProgressScope = import 'LrProgressScope'
local LrTasks = import 'LrTasks'
local LrView = import 'LrView'

local helpers = require 'helpers'

local log = LrLogger('MLDualISO')
--local debug, info, warn, err, trace = logger:quick( 'debug', 'info', 'warn', 'err', 'trace' )
log:enable( "print" )

local bind = LrView.bind
local share = LrView.share
local ExecLabelColor = LrColor("dark gray")
local inputSize = 600
local blackLevelDefaults = {
    min = 0,
    max = 10000,
    default = 2048
}

local whiteLevelDefaults = {
    min = 0,
    max = 20000,
    default = 15000
}

local prefs = LrPrefs.prefsForPlugin()

local catalog = LrApplication:activeCatalog()

function getSubfolder(prefs, path, createFolder)
    if prefs.subfolder then
        prefs.path_output = LrPathUtils.removeExtension(path)
        prefs.output_suffix = LrPathUtils.child(prefs.path_output, LrPathUtils.leafName(prefs.path_output)) .. "_"
        if prefs.davinci_compliance then
            prefs.davinci_base = string.format("%s_1_%s_0001_C0000", prefs.path_output, prefs.mlv_dates[path]['date'])
            prefs.path_output = prefs.davinci_base
            prefs.output_suffix = LrPathUtils.child(prefs.path_output, LrPathUtils.leafName(prefs.davinci_base)) .. "_"
        end
        if prefs.video_info then
            prefs.path_output = string.format("%s_%s_frames_%s_fps", prefs.path_output, prefs.mlv_dates[path]['frames'], prefs.mlv_dates[path]['fps'] / 1000)
            prefs.output_suffix = LrPathUtils.child(prefs.path_output, LrPathUtils.leafName(prefs.path_output)) .. "_"
        end
        if createFolder then
            LrFileUtils.createDirectory(prefs.path_output)
        end
    else
        prefs.path_output = LrPathUtils.parent(path)
        prefs.output_suffix = LrPathUtils.removeExtension(path) .. "_"
    end
end

function checkPathMLV(propertyTable, key, value)

    if LrFileUtils.exists(propertyTable.path_mlv) == false then
        LrDialogs.message("File doesn't exists")
        propertyTable.actionEnabled = false
        return false
    end
    if string.lower(LrPathUtils.extension(propertyTable.path_mlv)) ~= "mlv" then
        LrDialogs.message("File isn't MLV")
        propertyTable.actionEnabled = false
        return false
    end

    enableSubfolders(propertyTable)
    getSubfolder(propertyTable, propertyTable.path_mlv, false)

    propertyTable.enable_subfolder = true
    propertyTable.actionEnabled = true
end

function checkPathOutput(propertyTable, key, value)
    if LrFileUtils.exists(value) == false then
        LrDialogs.message("Output " .. value .. " path doesn't exists")
        return false
    end
end

function resetSettingsFunc(propertyTable)
    propertyTable.mlv_cs = 0
    propertyTable.cold_pixel = 1
    propertyTable.stripes = 1
    propertyTable.blackfix_enabled = false
    propertyTable.blackfix = blackLevelDefaults.default
    propertyTable.whitefix_enabled = false
    propertyTable.whitefix = whiteLevelDefaults.default
    propertyTable.subfolder = true
    propertyTable.video_info = false
    propertyTable.davinci_compliance = false
    propertyTable.applyToAll = false
end

function enableSubmit(propertyTable)
    if propertyTable.applyToAll == true then
        propertyTable.actionEnabled = true
    end
end

function generateMLVCmd(args, inputFile, output)
    local pluginPath = _PLUGIN.path
    local exec = "mlv_dump"
    local gt = " > "
    local cmd = WIN_ENV and 'start /D "%s\\bin" /B /WAIT /BELOWNORMAL %s.exe%s "%s"' or 'exec "%s/bin/%s"%s "%s"'

    local escape = WIN_ENV and '"%s"' or '%s'

    local finalCmd = string.format(escape,
        string.format('%s%s"%s"',
            string.format(cmd,
                pluginPath,
                exec,
                args,
                inputFile
            ),
            gt,
            output)
    )
    return finalCmd
end

function generateBWFCmd(inputFile, xml)
    local pluginPath = _PLUGIN.path
    local exec = "bwfmetaedit"
    local args = string.format(' --in-iXML="%s"', xml)
    local cmd = WIN_ENV and 'start /D "%s\\bin" /B /WAIT /BELOWNORMAL %s.exe%s "%s"' or 'exec "%s/bin/%s"%s "%s"'

    local escape = WIN_ENV and '"%s"' or '%s'

    local finalCmd = string.format(escape,
        string.format(cmd,
            pluginPath,
            exec,
            args,
            inputFile
        )
    )
    return finalCmd
end

function generateMLVArgs(exportSettings)

    local args = string.format(' --dng%s%s%s%s%s',
        exportSettings.mlv_cs == 0 and " --no-cs" or string.format(" --cs%dx%d", exportSettings.mlv_cs, exportSettings.mlv_cs),
        exportSettings.cold_pixel == 0 and " --no-fixcp" or exportSettings.cold_pixel == 2 and " --fixcp2" or "",
        exportSettings.stripes == 1 and " --no-stripes" or "",
        exportSettings.blackfix_enabled and " --black-fix=" .. exportSettings.blackfix or "",
        exportSettings.whitefix_enabled and " --white-fix=" .. exportSettings.whitefix or ""
    )

    return args
end

function sanitize(s)
    return s:gsub("[%(%)%.%+%-%*%?%[%]%^%$%%]", "")
end

function enableSubfolders(propertyTable)
    if propertyTable.video_info then
        propertyTable.enableDavinci = false
    else
        propertyTable.enableDavinci = true
    end

    if propertyTable.davinci_compliance then
        propertyTable.enableVideoInfo = false
    else
        propertyTable.enableVideoInfo = true
    end

    if not propertyTable.subfolder then
        propertyTable.davinci_compliance = false
        propertyTable.enableDavinci = false
        propertyTable.video_info = false
        propertyTable.enableVideoInfo = false
    end
end

function displayMLVGUI()
    local result

    LrFunctionContext.callWithContext("cr2hdr Import MLV", function(context)

        LrDialogs.attachErrorDialogToFunctionContext(context)

        context:addFailureHandler(
            function(status, message)
                if not status then
                    LrDialogs.message("ERROR", string.format("Please report the problem\n\n%s", message), "critical")
                end
            end
        )

        local f = LrView.osFactory()
        local props = LrBinding.makePropertyTable(context)

        props.actionEnabled = false
        props.applyToAll = false

        props.subfolder = prefs.subfolder == nil and true or prefs.subfolder
        props.enable_subfolder = false
        props.enableVideoInfo = false
        props.enableDavinci = false
        props.video_info = false
        props.davinci_compliance = false
        props.davinci_base = nil
        props.path_mlv = false
        props.mlv_cs = prefs.mlv_cs == nil and 0 or prefs.mlv_cs
        props.cold_pixel = prefs.cold_pixel == nil and 1 or prefs.cold_pixel
        props.stripes = prefs.stripes == nil and 1 or prefs.stripes
        props.blackfix_enabled = false
        props.blackfix = prefs.blackfix == nil and 2048 or prefs.blackfix

        props.whitefix_enabled = false
        props.whitefix = props.whitefix == nil and 15000 or prefs.whitefix

        props:addObserver('path_mlv', checkPathMLV)
        props:addObserver('subfolder', checkPathMLV)
        props:addObserver('davinci_compliance', checkPathMLV)
        props:addObserver('video_info', checkPathMLV)
        props:addObserver('applyToAll', enableSubmit)
        props:addObserver('subfolder', enableSubfolders)
        props:addObserver('davinci_compliance', enableSubfolders)
        props:addObserver('video_info', enableSubfolders)

        props.activeFolder = nil
        props.activeFolderStatus = false
        local sources = catalog:getActiveSources()
        if #sources == 1 and type(sources[1]) == "table" and sources[1]:type() == "LrFolder" and LrFileUtils.exists(sources[1]:getPath()) then
            props.path_output = sources[1]:getPath()
        else
            LrDialogs.message("You need to select an existing folder inside Lightroom to be able to execute this plugin.")
            return false
        end

        LrDialogs.showBezel("Read metadata from MLV files", 1)

        local mlvFiles = {}
        local mlvDates = {}
        for file in LrFileUtils.files(props.path_output) do
            if string.lower(LrPathUtils.extension(file)) == "mlv" then

                local logfile = LrPathUtils.removeExtension(file) .. "_metadata.TXT"
                local command = generateMLVCmd(" -m -v", file, logfile)
                local result_date = LrTasks.execute(command)
                if result_date == 0 then
                    logToParse = LrFileUtils.readFile(logfile)

                    mlvDates[file] = {
                        date = logToParse:match('%s*Date%s*:%s*([%S ]+)%s*'):gsub("(%d+).(%d+).(%d+)", "%3-%2-%1"),
                        fps = tonumber(logToParse:match('%s*FPS%s*:%s*([%S ]+)%s*')) * 1000,
                        frames = logToParse:match('Processed (%d+) video frames')
                    }

                    mlvFiles[#mlvFiles + 1] = {
                        title = string.format("%s on %s, %s (%s frames @ %s fps)", file, mlvDates[file]['date'], helpers.secondsToClock(mlvDates[file]['frames'] / (mlvDates[file]['fps'] / 1000)), mlvDates[file]['frames'], mlvDates[file]['fps'] / 1000),
                        value = file
                    }
                    LrFileUtils.delete(logfile)
                end
            end
        end

        if #mlvFiles == 0 then
            LrDialogs.message("Folder contains no MLV file")
            return false
        end

        props.mlv_files = mlvFiles
        props.mlv_dates = mlvDates

        props.path_mlv = props.mlv_files[1]['value']

        local path_mlv_list = f:view {
            place = horizontal,
            f:row {
                font = "<system>",
                bind_to_object = props,
                f:static_text {
                    title = "MLV path:",
                    width = LrView.share "label_width",
                },
                f:popup_menu {
                    value = LrView.bind('path_mlv'),
                    items = mlvFiles,
                    width = inputSize
                }
            }
        }

        local path_output = f:view {
            place = horizontal,
            f:row {
                font = "<system>",
                bind_to_object = props,

                f:static_text {
                    title = "Output path:",
                    width = LrView.share "label_width",
                },
                f:edit_field {
                    value = LrView.bind('path_output'),
                    width = inputSize,
                    enabled = false
                }
            }
        }

        local path_output_options = f:view {
            place = horizontal,
            f:row {
                font = "<system>",
                bind_to_object = props,
                f:static_text {
                    width = LrView.share "label_width",
                    title = "Path option:",
                },
                f:checkbox {
                    value = bind 'subfolder',
                    checked_value = true,
                    unchecked_value = false,
                    --enabled = bind 'enable_subfolder'
                },
                f:static_text {
                    text_color = ExecLabelColor,
                    title = "subfolder",
                },
                f:checkbox {
                    value = bind 'video_info',
                    checked_value = true,
                    unchecked_value = false,
                    enabled = bind 'enableVideoInfo'
                },
                f:static_text {
                    text_color = ExecLabelColor,
                    title = "Video info",
                },
                f:checkbox {
                    value = bind 'davinci_compliance',
                    checked_value = true,
                    unchecked_value = false,
                    enabled = bind 'enableDavinci'
                },
                f:static_text {
                    text_color = ExecLabelColor,
                    title = "davinci compliance",
                },
            }
        }

        local path_output_info = f:view {
            place = horizontal,
            f:row {
                font = "<system>",
                text_color = LrColor("gray"),
                f:spacer {
                    width = LrView.share "label_width",
                },
                f:static_text {
                    title = "The script will move the .mlv file in this folder, if it is not already in it."
                }
            }
        }

        local separator = f:separator {
            fill_horizontal = 100
        }

        local chromaSmooth = f:view {
            place = horizontal,
            f:row {
                font = "<system>",
                bind_to_object = props,
                f:static_text {
                    width = share 'labelExecWidth',
                    title = LOC "$$$/ML/ExportManager/CRTab2Cs=Chroma smoothing:",
                    font = {
                        name = "<system>",
                        size = 10
                    },
                },
                f:radio_button {
                    tooltip = LOC "$$$/ML/ExportManager/TTNoCs=disable chroma smoothing",
                    value = LrView.bind('mlv_cs'),
                    checked_value = 0,
                },
                f:static_text {
                    text_color = ExecLabelColor,
                    title = "no-cs",
                    width = share 'radioExecWidth1',
                },
                f:radio_button {
                    tooltip = LOC "$$$/ML/ExportManager/TTCs2=apply 2x2 chroma smoothing in noisy and aliased areas (default)",
                    value = LrView.bind('mlv_cs'),
                    checked_value = 2,
                },
                f:static_text {
                    text_color = ExecLabelColor,
                    title = "cs2x2",
                    width = share 'radioExecWidth1',
                },
                f:radio_button {
                    tooltip = LOC "$$$/ML/ExportManager/TTCs3=apply 3x3 chroma smoothing in noisy and aliased areas",
                    value = LrView.bind('mlv_cs'),
                    checked_value = 3,
                },
                f:static_text {
                    text_color = ExecLabelColor,
                    title = "cs3x3",
                    width = share 'radioExecWidth1',
                },
                f:radio_button {
                    tooltip = LOC "$$$/ML/ExportManager/TTCs5=apply 5x5 chroma smoothing in noisy and aliased areas",
                    value = LrView.bind('mlv_cs'),
                    checked_value = 5,
                },
                f:static_text {
                    text_color = ExecLabelColor,
                    title = "cs5x5",
                    width = share 'radioExecWidth1',
                },
            }
        }

        local coldPixel = f:view {
            place = horizontal,
            f:row {
                font = "<system>",
                bind_to_object = props,
                f:static_text {
                    width = share 'labelExecWidth',
                    title = LOC "$$$/ML/MLVImport/ColdPixelTitle=Cold Pixel:",
                    font = {
                        name = "<system>",
                        size = 10
                    },
                },
                f:radio_button {
                    tooltip = LOC "$$$/ML/MLVImport/ColdPixelNoCP=do not fix cold pixels",
                    value = LrView.bind('cold_pixel'),
                    checked_value = 0,
                },
                f:static_text {
                    text_color = ExecLabelColor,
                    title = "no-fixcp",
                    width = share 'radioExecWidth1',
                },
                f:radio_button {
                    tooltip = LOC "$$$/ML/MLVImport/ColdPixelCP=fix cold pixels",
                    value = LrView.bind('cold_pixel'),
                    checked_value = 1,
                },
                f:static_text {
                    text_color = ExecLabelColor,
                    title = "fixcp",
                    width = share 'radioExecWidth1',
                },
                f:radio_button {
                    tooltip = LOC "$$$/ML/MLVImport/ColdPixelCP2=fix non-static (moving) cold pixels (slow)",
                    value = LrView.bind('cold_pixel'),
                    checked_value = 2,
                },
                f:static_text {
                    text_color = ExecLabelColor,
                    title = "fixcp2",
                    width = share 'radioExecWidth1',
                }
            }
        }

        local verticalStripes = f:view {
            place = horizontal,
                f:row {
                font = "<system>",
                bind_to_object = props,
                f:static_text {
                    width = share 'labelExecWidth',
                    title = LOC "$$$/ML/MLVImport/VerticalStripesTitle=Vertical stripes:",
                    font = {
                        name = "<system>",
                        size = 10
                    },
                },
                f:checkbox {
                    tooltip = LOC "$$$/ML/MLVImport/VerticalStripesNoFix=do not fix vertical stripes in highlights",
                    value = bind 'stripes',
                    checked_value = 1,
                    unchecked_value = 0,
                },
                f:static_text {
                    text_color = ExecLabelColor,
                    title = "no-stripes",
                    width = share 'radioExecWidth1',
                }
                }
        }

        local blackFix = f:view {
            place = horizontal,
            f:row {
                font = "<system>",
                bind_to_object = props,
                f:static_text {
                    width = share 'labelExecWidth',
                    title = LOC "$$$/ML/MLVImport/BlackFixTitle=Fix black level:",
                    font = {
                        name = "<system>",
                        size = 10
                    },
                },
                f:checkbox {
                    value = bind 'blackfix_enabled',
                    checked_value = true,
                    unchecked_value = false,
                },
                f:static_text {
                    text_color = ExecLabelColor,
                    title = "set value",
                },
                f:slider {
                    value = LrView.bind('blackfix'),
                    min = blackLevelDefaults.min,
                    max = blackLevelDefaults.max,
                    tooltip = LOC "$$$/ML/ExportManager/BlackFixTooltip=set black level to <value> (fix green/magenta cast). if no value given, it will be set to 2048.",
                    integral = true,
                    enabled = bind 'blackfix_enabled',
                    place_vertical = 0.5
                },
                f:edit_field {
                    value = LrView.bind('blackfix'),
                    width = 50,
                    enabled = bind 'blackfix_enabled',
                    immediate = true,
                    validate = function (view, value)
                        local result = true
                        local message = nil

                        if value:match("%D") or value == "" then
                            result = false
                            value = blackLevelDefaults.default
                            message = "Only digits is allowed"
                        end

                        value = tonumber(value)

                        if value > blackLevelDefaults.max then
                            result = false
                            value = blackLevelDefaults.max
                            message = "Value to high, max is " .. blackLevelDefaults.max
                        end
                        if value < blackLevelDefaults.min then
                            result = false
                            value = blackLevelDefaults.min
                            message = "Value to low, min is " .. blackLevelDefaults.min
                        end

                        return result, value, message
                    end
                }
            }
        }

        local whiteFix = f:view {
            place = horizontal,
            f:row {
                font = "<system>",
                bind_to_object = props,
                f:static_text {
                    width = share 'labelExecWidth',
                    title = LOC "$$$/ML/MLVImport/WhiteFixTitle=Fix white level:",
                    font = {
                        name = "<system>",
                        size = 10
                    },
                },
                f:checkbox {
                    value = bind 'whitefix_enabled',
                    checked_value = true,
                    unchecked_value = false,
                },
                f:static_text {
                    text_color = ExecLabelColor,
                    title = "set value",
                },
                f:slider {
                    value = bind 'whitefix',
                    min = 0,
                    max = 20000,
                    tooltip = LOC "$$$/ML/ExportManager/WhiteFixTooltip=set white level to <value>. if no value given, it will be set to 15000.",
                    integral = true,
                    enabled = bind 'whitefix_enabled',
                    place_vertical = 0.5
                },
                f:edit_field {
                    value = LrView.bind('whitefix'),
                    width = 50,
                    enabled = bind 'whitefix_enabled',
                    immediate = true,
                    validate = function (view, value)
                        local result = true
                        local message = nil

                        if value:match("%D") or value == "" then
                            result = false
                            value = whiteLevelDefaults.default
                            message = "Only digits is allowed"
                        end

                        value = tonumber(value)

                        if value > whiteLevelDefaults.max then
                            result = false
                            value = whiteLevelDefaults.max
                            message = "Value to high, max is " .. whiteLevelDefaults.max
                        end
                        if value < whiteLevelDefaults.min then
                            result = false
                            value = whiteLevelDefaults.min
                            message = "Value to low, min is " .. whiteLevelDefaults.min
                        end

                        return result, value, message
                    end
                }
            }
        }

        local applyToAll = f:view {
            place = horizontal,
            f:row {
                font = "<system>",
                bind_to_object = props,

                f:checkbox {
                    value = bind 'applyToAll',
                    checked_value = true,
                    unchecked_value = false,
                },
                f:static_text {
                    title = "Apply these settings to every MLV files (" .. #mlvFiles .. " files)",
                    text_color = ExecLabelColor,
                },
            }
        }


        local resetSettings = f:view {
            place = horizontal,
            place_horizontal = 1,
            f:row {
                f:push_button {
                    font = "<system>",
                    title = "Reset settings to default",
                    size = "regular",
                    action = function()
                        resetSettingsFunc(props)
                    end
                }
            }
        }

        local content = f:column {
            spacing = f:dialog_spacing(),
            f:group_box {
                title = "Choose options for mlv_dump",
                font = "<system/bold>",
                path_mlv_list,
                path_output,
                path_output_options,
                separator,
                chromaSmooth,
                coldPixel,
                verticalStripes,
                blackFix,
                whiteFix,
                applyToAll,
                resetSettings
            }
        }

        result = LrDialogs.presentModalDialog {
            title = "Convert MLV to DNG files and import it in Lightroom",
            contents = content,
            actionBinding = {
                enabled = {
                    bind_to_object = props,
                    key = 'actionEnabled'
                },
            }
        }

        for k, v in pairs(props['< contents >']) do
            prefs[k] = v
        end
    end)

    return result == "ok" and true or false
end

LrTasks.startAsyncTask(function ()

    if displayMLVGUI() then
        local filesToProcess = {}
        if prefs.applyToAll then
            for i, j in pairs(prefs.mlv_files) do
                table.insert(filesToProcess, j['value'])
            end
        else
            table.insert(filesToProcess, prefs.path_mlv)
        end

        if #filesToProcess == 0 then
            LrDialogs.message("You need to select a MLV file")
            return false
        end

        local progressParent = LrProgressScope {
            title = "Convert MLV to DNG"
        }
        progressParent:setCancelable(false)

        for nb, path_mlv in pairs(filesToProcess) do

            progressParent:setCaption("Convert " .. LrPathUtils.leafName(path_mlv) .. " to DNG")

            getSubfolder(prefs, path_mlv, true)

            LrDialogs.showBezel("mlv_dump process file " .. LrPathUtils.leafName(path_mlv), 2)

            local args = generateMLVArgs(prefs)
            args = string.format('%s -o "%s"', args, prefs.output_suffix)
            local command = generateMLVCmd(args, path_mlv, LrPathUtils.replaceExtension(path_mlv, "TXT"))


            local result = LrTasks.execute(command)
            if result == 0 then
                local wavFile = prefs.output_suffix .. ".wav"
                local base = prefs.output_suffix:sub(#prefs.output_suffix, #prefs.output_suffix) == "_" and prefs.output_suffix:sub(1, -2) or prefs.output_suffix
                local ixml = string.format('<?xml version="1.0" encoding="UTF-8"?><BWFXML><IXML_VERSION>1.5</IXML_VERSION><PROJECT>Magic Lantern</PROJECT><NOTE></NOTE><CIRCLED>FALSE</CIRCLED><BLACKMAGIC-KEYWORDS></BLACKMAGIC-KEYWORDS><TAPE>1</TAPE><SCENE>1</SCENE><BLACKMAGIC-SHOT>1</BLACKMAGIC-SHOT><TAKE>1</TAKE><BLACKMAGIC-ANGLE>ms</BLACKMAGIC-ANGLE><SPEED><MASTER_SPEED>%s/1000</MASTER_SPEED><CURRENT_SPEED>%s/1000</CURRENT_SPEED><TIMECODE_RATE>%s/1000</TIMECODE_RATE><TIMECODE_FLAG>NDF</TIMECODE_FLAG></SPEED></BWFXML>', prefs.mlv_dates[path_mlv]['fps'], prefs.mlv_dates[path_mlv]['fps'], prefs.mlv_dates[path_mlv]['fps'])

                local ixmlFile = base .. ".xml"
                local file = io.open(ixmlFile, "w")
                file:write(ixml)
                file:close()

                local wav_command = generateBWFCmd(wavFile, ixmlFile)
                local wav_result = LrTasks.execute(wav_command)

                if LrFileUtils.exists(base .. "_.wav") then
                    LrFileUtils.move(base .. "_.wav", base .. ".wav")
                end

                LrDialogs.showBezel("Import DNG files in Lightroom, be patient", 2)

                local importDualiso = catalog:withWriteAccessDo('Import DNG from MLV file', function(context)
                    local progress = LrProgressScope {
                        parent = progressParent,
                        title = "Importing DNG files",
                        parentEndRange = nb / #filesToProcess
                    }
                    progress:setCancelable(false)
                    local i = 1
                    for file in LrFileUtils.files(prefs.path_output) do
                        if sanitize(LrPathUtils.leafName(file)):gmatch("^" .. sanitize(path_mlv)) and string.lower(LrPathUtils.extension(file)) == "dng" then
                            local photo = catalog:addPhoto(file)
                            progress:setPortionComplete(i, prefs.mlv_dates[path_mlv]['frames'])
                            i = i + 1
                        end
                    end
                    progress:done()
                end)
                LrDialogs.showBezel("MLV importation finished !", 3)
            else
                LrDialogs.showBezel("Unable to run mlv_dump", 2)
            end

            progressParent:setPortionComplete(nb, #filesToProcess)

        end

        progressParent:done()

    end

end)