--[[

    cr2hdr.lrplugin is a plugin for Adobe Photoshop Lightroom
    to convert Dual ISO picture from Magic Lantern.
    http://www.magiclantern.fm/forum/index.php?topic=7139.0

    Copyright (C) <2015> <Christophe Francey kichetof@gmail.com>

    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License
    as published by the Free Software Foundation; either version 2
    of the License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

]]--

local LrBinding = import 'LrBinding'
local LrHttp = import 'LrHttp'
local LrFileUtils = import 'LrFileUtils'
local LrPathUtils = import 'LrPathUtils'
local LrPrefs = import 'LrPrefs'
local LrShell = import 'LrShell'
local LrView = import "LrView"

local pluginInfo = require 'Info'

local bind = LrView.bind
local share = LrView.share
local prefs = LrPrefs.prefsForPlugin()

local pluginInfoProvider = {}

pluginInfoProvider.sectionsForTopOfDialog = function(f, propertyTable)

    local firstSection = {
            title = LOC ("$$$/ML/ExportManager/Title=Magic Lantern Dual ISO (Plugin version ^1)", pluginInfo.VERSION.display),
            f:row {
                f:picture {
                    value = _PLUGIN:resourceId("logo.png"),
                },
            },
            f:row {
                f:push_button {
                    title = LOC "$$$/ML/ExportManager/MLTopic=Magic Lantern Dual ISO thread",
                    action = function()
                        LrHttp.openUrlInBrowser("http://www.magiclantern.fm/forum/index.php?topic=7139.0")
                    end,
                },
                f:push_button {
                    title = LOC "$$$/ML/ExportManager/MLDocTech=Technical doc",
                    action = function()
                        LrHttp.openUrlInBrowser("http://acoutts.com/a1ex/dual_iso.pdf")
                    end,
                },
                f:spacer {
                    height = 20
                },
            },
            f:row {
                f:push_button {
                    title = LOC "$$$/ML/InfoProvider/PlugInTopic=Dual ISO Converter plug-in thread",
                    action = function()
                        LrHttp.openUrlInBrowser("http://magiclantern.fm/forum/index.php?topic=11056.0")
                    end,
                },
                f:push_button {
                    title = LOC "$$$/ML/InfoProvider/Bitbucket=Bitbucket Project",
                    action = function()
                        LrHttp.openUrlInBrowser("https://bitbucket.org/kichetof/lr_cr2hdr")
                    end,
                },
            }
    }

    local secondSection = {
        title = LOC "$$$/ML/InfoProvider/FPTitle=Library Filter",
        f:row {
            f:static_text {
                title = LOC "$$$/ML/InfoProvider/FPHeader=Prevents copying",
                font = "<system/bold>"
            }
        },
        f:row {
            f:checkbox {
                size = "small",
                value = bind {
                    key = 'copyFilterPresets',
                    bind_to_object = prefs
                },
                checked_value = true,
                unchecked_value = false
            },
            f:static_text {
                title = LOC "$$$/ML/InfoProvider/FPCheckBoxInfo=Uncheck this option to disable copying presets",
            }
        },
        f:row {
            f:static_text {
                title = LOC "$$$/ML/InfoProvider/FPPath=Path:",
                width = share 'pathWidth',
            },
            f:static_text {
                title = LrPathUtils.child(LrPathUtils.getStandardFilePath('appData'), 'Filter Presets')
            }
        },
        f:row {
            f:spacer {
                width = share 'pathWidth',
            },
            f:push_button {
                title = windowManager == WIN_ENV and LOC "$$$/ML/InfoProvider/FPButtonRevealWin=Show in Windows Explorer" or LOC "$$$/ML/InfoProvider/FPButtonRevealMac=Show in Finder",
                action = function()
                    LrShell.revealInShell(LrPathUtils.child(LrPathUtils.child(LrPathUtils.getStandardFilePath('appData'), 'Filter Presets'), 'Dual-ISO 100-400.lrtemplate'))
                end,
            }
        },
        f:row {
            f:static_text {
                title = LOC "$$$/ML/InfoProvider/FPDeleteInfo=If you want to remove these filter presets, delete these files:"
            }
        },
        f:row {
            f:spacer {
                width = share 'pathWidth',
            },
            f:static_text {
                title = LOC "$$$/ML/InfoProvider/FPDeleteFiles=- Dual-ISO 100-400.lrtemplate\n- Dual-ISO raw.lrtemplate\n- Dual-ISO.lrtemplate\n- No Dual-ISO.lrtemplate"
            }
        }
    }

    local sections = {}
    table.insert(sections, firstSection)
    table.insert(sections, secondSection)

    return sections
end

pluginInfoProvider.sectionsForBottomOfDialog = function( f, propertyTable )
    return {
        {
            title = LOC "$$$/ML/License/Title=Magic Lantern Dual ISO Lightroom Plugin License",
            synopsis = "GNU GPL v2",
            visible = false,
            f:row {
                spacing = f:control_spacing(),

                f:static_text {
                    title = LrFileUtils.readFile(_PLUGIN:resourceId("LICENSE.txt"))
                }
            }
        }
    }
end

return pluginInfoProvider
