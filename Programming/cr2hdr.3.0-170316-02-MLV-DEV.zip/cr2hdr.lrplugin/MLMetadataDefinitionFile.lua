--[[

    cr2hdr.lrplugin is a plugin for Adobe Photoshop Lightroom
    to convert Dual ISO picture from Magic Lantern.
    http://www.magiclantern.fm/forum/index.php?topic=7139.0

    Copyright (C) <2015> <Christophe Francey kichetof@gmail.com>

    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License
    as published by the Free Software Foundation; either version 2
    of the License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

]]--

return {

    metadataFieldsForPhotos = {
        {
            id = 'DualISOConverter',
        },
        {
            id = 'ISOdifference',
            title = LOC "$$$/ML/Metadata/ISOdifference=ISO difference",
            dataType = 'string',
            searchable = true,
            browsable = true,
            readOnly = true,
            version = 3,
        },
        {
            id = 'DynamicRange',
            title = LOC "$$$/ML/Metadata/DynamicRange=Dynamic range",
            dataType = 'string',
            searchable = true,
            browsable = true,
            readOnly = true,
            version = 3,
        },
        {
            id = 'DynamicRangeOrig1',
            title = LOC "$$$/ML/Metadata/DynamicRangeOrig1=Dynamic range (src1)",
            dataType = 'string',
            searchable = true,
            browsable = true,
            readOnly = true,
            version = 3,
        },
        {
            id = 'DynamicRangeOrig2',
            title = LOC "$$$/ML/Metadata/DynamicRangeOrig2=Dynamic range (src2)",
            dataType = 'string',
            searchable = true,
            browsable = true,
            readOnly = true,
            version = 3,
        },
        {
            id = 'SemiOverexposed',
            title = LOC "$$$/ML/Metadata/SemiOverexposed=Semi-overexposed",
            dataType = 'string',
            searchable = true,
            browsable = true,
            readOnly = true,
            version = 3,
        },
        {
            id = 'DeepShadows',
            title = LOC "$$$/ML/Metadata/DeepShadows=Deep shadows",
            dataType = 'string',
            searchable = true,
            browsable = true,
            readOnly = true,
            version = 3,
        },
        {
            id = 'ISOoverlap',
            title = LOC "$$$/ML/Metadata/ISOoverlap=ISO overlap",
            dataType = 'string',
            searchable = true,
            browsable = true,
            readOnly = true,
            version = 3,
        },
        {
            id = 'NoiseLevel',
            title = LOC "$$$/ML/Metadata/NoiseLevel=Noise level",
            dataType = 'string',
            searchable = true,
            browsable = true,
            readOnly = true,
            version = 3,
        },
        {
            id = 'NoiseLevelIdeal',
            title = LOC "$$$/ML/Metadata/NoiseLevelIdeal=Noise level (ideal)",
            dataType = 'string',
            searchable = true,
            browsable = true,
            readOnly = true,
            version = 3,
        },
        {
            id = 'cr2hdrExec',
            title = LOC "$$$/ML/Metadata/cr2hdrExec=Executable",
            dataType = 'string',
            searchable = true,
            browsable = true,
            readOnly = true,
            version = 3,
        },
        {
            id = 'cr2hdrVersion',
            title = LOC "$$$/ML/Metadata/cr2hdrVersion=Version",
            dataType = 'string',
            searchable = true,
            browsable = true,
            readOnly = true,
            version = 3,
        },
        {
            id = 'cr2hdrArgs',
            title = LOC "$$$/ML/Metadata/cr2hdrArgs=Active options",
            dataType = 'string',
            searchable = true,
            browsable = true,
            readOnly = false,
            version = 3,
        },
        {
            id = 'cr2hdrISORange',
            title = LOC "$$$/ML/Metadata/cr2hdrISORange=ISO Range",
            dataType = 'string',
            searchable = true,
            browsable = true,
            readOnly = true,
            version = 3,
        },
    },

    schemaVersion = 9, -- BETA was 6

    updateFromEarlierSchemaVersion = function(catalog, previousSchemaVersion, progressScope)
        catalog:assertHasPrivateWriteAccess("DualISOConverter.updateFromEarlierSchemaVersion")

        local myPluginId = 'com.adobe.lightroom.export.ml.dualiso'

        if previousSchemaVersion == 6 then
            local photosToMigrate = catalog:findPhotosWithProperty(myPluginId, 'ISOdifference')

            for i, photo in ipairs( photosToMigrate ) do

                local isoFirst = tonumber(photo:getRawMetadata("isoSpeedRating"))
                local getISOdiff = photo:getPropertyForPlugin(myPluginId, 'ISOdifference'):gsub(" EV", "")

                if isoFirst ~= nil and getISOdiff ~= nil then

                    local isoRange = string.format("%s - %s", isoFirst, 2^math.floor(tonumber(getISOdiff)+0.5)*isoFirst)
                    photo:setPropertyForPlugin(_PLUGIN, 'cr2hdrISORange', isoRange)

                end
            end
        end
    end,
}
