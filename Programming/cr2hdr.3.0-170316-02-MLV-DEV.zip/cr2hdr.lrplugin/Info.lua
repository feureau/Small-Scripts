--[[

    cr2hdr.lrplugin is a plugin for Adobe Photoshop Lightroom
    to convert Dual ISO picture from Magic Lantern.
    http://www.magiclantern.fm/forum/index.php?topic=7139.0

    Copyright (C) <2015> <Christophe Francey kichetof@gmail.com>

    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public License
    as published by the Free Software Foundation; either version 2
    of the License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

]]--

return {

    LrToolkitIdentifier = 'com.adobe.lightroom.export.ml.dualiso',
    LrPluginName = 'Dual ISO Converter',
    LrPluginInfoUrl = 'http://www.magiclantern.fm/forum/index.php?topic=7139.0',
    LrSdkVersion = 6.0,
    LrSdkMinimumVersion = 4.0,

    LrMetadataProvider = "MLMetadataDefinitionFile.lua",
    LrMetadataTagsetFactory = "MLMetadataTagset.lua",

    LrExportServiceProvider = {
        title = LOC "$$$/ML/ExportDialog/ExportMenu/Title=Magic Lantern",
        file = 'MLExportServiceProvider.lua',
        builtInPresetsDir = "presets",
        id = "",
    },

    LrLibraryMenuItems = {
        {
            title = "Import MLV file",
            file = "importMLV.lua",
        }
    },

    LrForceInitPlugin = true,
    LrPluginInfoProvider = "MLInfoProvider.lua",

    VERSION = {
        major=3,
        minor=0,
        revision=20,
        build=2017031602,
        display="3.0-170316-02-MLV-DEV" -- MLV support branch
    },
}
