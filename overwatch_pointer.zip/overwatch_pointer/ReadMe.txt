## Overwatch Pointer Set ##

- Install by right-clicking the "Install.inf" file, then select "Install".

Replace files/cursors as you want through the windows mouse settings.

NOTE: Set originally made by Darques, I didn't make this set I just changed some of cursors with my own as I thought they didn't looked coherent. The original text line looks awful, lol.


Enjoy,

_starf