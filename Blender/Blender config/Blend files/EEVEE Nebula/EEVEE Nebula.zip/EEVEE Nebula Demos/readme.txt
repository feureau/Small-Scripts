Thank you for the support! :)

---
Social Links:
www.youtube.com/CurtisHolt
www.twitter.com/curtisjamesholt
www.instagram.com/curtisjamesholt/
www.artstation.com/curtisjamesholt
---
Discord Server:
https://discord.gg/aMDpFtc
---